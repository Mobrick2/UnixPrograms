#ifndef _HTTP_H
#define _HTTP_H

#include <stdlib.h>
#include <sys/types.h>
#include <dirent.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <limits.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <ctype.h>
#include <libgen.h>
#include <magic.h>
#include <time.h>

#ifndef BUFFSIZE
#define BUFFSIZE 1024
#endif

#ifndef MAXLEN
#define MAXLEN 1048576
#endif

void 
time_out(int client);

int 
is_valid_version(char *version_char_array);

int
is_http_method(char *method_char_array);

void
bad_request(int client);

void 
version_error(int client);

void
unimplemented(int client);

void
not_found(int client);

void
transport( int client, FILE *resource);

void 
sendheaders(int client, char *filename);

void
send_file(int client, char *filename);

void
checkfiletype(char * filename, char * filetype);

char **
getentryinpath(char * pathname, int * count);

void send_content(int client, char * filename);

void
freechararray(char ** entry, int n);

void transportBinary(int client, FILE *resource);

void transport2(int client, FILE * resource);

void getgmt(char * buf, struct tm* temp);

void
entrysort(char ** entry, int entrynum);
#endif
