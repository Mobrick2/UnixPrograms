#include "net.h"
#include "http.h"
/******************************************************/
/*This function initilize the attribute in the ipv4 
 *address struct, and create the connections to the client
 *Input: the port the server receive the request
 *Return :  the socket*/
/******************************************************/
int startup1( int *port, char * options, struct sockaddr_in *server){
   int sok_fd = 0;
   
   sok_fd =  socket(PF_INET, SOCK_STREAM, 0);
   if ( sok_fd == -1 ){
      fprintf(stderr,"cannot create socket : %s\n",strerror(errno));
      exit(EXIT_FAILURE);
   }
  
   server->sin_family = AF_INET;
   server->sin_port = htons(*port);
   if ( options[3] == 0 ){
      server->sin_addr.s_addr = htonl(INADDR_ANY);
   }
   //when options[3] = 4, the server.sin_addr.s_addr is set in the 
   //checkoptions function

   if ( bind(sok_fd, (struct sockaddr *)server, sizeof(*server)) < 0){
      fprintf(stderr,"cannot bind port #%d : %s\n", *port, strerror(errno));
      exit(EXIT_FAILURE);
   }

   if( listen(sok_fd,MAX_COLLECTIONS) < 0 ){
      fprintf(stderr,"cannot listen to socket %d : %s\n",sok_fd,strerror(errno));
      exit(EXIT_FAILURE);
   }

   return sok_fd;
}


/******************************************************/
/*This function initilize the attribute in the ipv6 
 *address struct, and create the connections to the client
 *Input: the port the server receive the request
 *Return :  the socket*/
/******************************************************/
int startup2( int *port, char * options, struct sockaddr_in6 *ipv6server){
   int sok_fd = 0;

   sok_fd =  socket(AF_INET6, SOCK_STREAM, 0);
   if ( sok_fd == -1 ){
      fprintf(stderr,"cannot create socket : %s\n",strerror(errno));
      exit(EXIT_FAILURE);
   }

   ipv6server->sin6_family = AF_INET6;
   ipv6server->sin6_port = htons(*port);
   if ( options[3] == 0 ){
      ipv6server->sin6_addr = in6addr_any;
   }
   //when options[3] = 6, the ipv6server.sin6_addr.s6_addr is set in the 
   //`checkoptions` function

   if ( bind(sok_fd, (struct sockaddr *)ipv6server, sizeof(*ipv6server)) < 0){
      fprintf(stderr,"cannot bind port #%d : %s\n", *port, strerror(errno));
      exit(EXIT_FAILURE);
   }

   if( listen(sok_fd,MAX_COLLECTIONS) < 0 ){
      fprintf(stderr,"cannot listen to socket %d : %s\n",sok_fd,strerror(errno));
      exit(EXIT_FAILURE);
   }
   return sok_fd;
}

/******************************************************/
/*This function read a header line from the request 
 *The header line must small than the buf size, if not
 *the header line will be truncated. And the end of the 
 *header line may or maynot end up with a carriage return
 *and the buf is always terminated with a null.  
 *Input: the socket number, the buffer, buffer size.
 *Return :  the length of the header line*/
/******************************************************/
int get_line(int client, char *buf, int size){
   int i = 0 ;
   char c = '\0';
   int n;
   
   while (( i < size - 1) && (c != '\n')){
      n = recv(client,&c,1,0);
      if( n == -1){
	  return -1;
      }
      if ( n > 0 ){
	  if ( c == '\r'){
	     n = recv(client,&c,1,MSG_PEEK);
	     if ((n > 0) && (c == '\n'))
		recv(client,&c,1,0);
	     else
		c = '\n';
	  }
	  buf[i] = c;
	  i++;
      }
      else
	c = '\n';
   }/******************************************************/
   buf[i] = '\0';

   return(i);
}

/******************************************************/
/*This function parsing the request method and deal with
 *client request. Return the content or execute the cgi
 *and the response headers*/
/******************************************************/
void send_response(int client, int logfd, char * basepath, 
		char *options, char *cgi_dir, char * swspath){
   char buf[BUFFSIZE];
   char path[BUFFSIZE];
   struct stat sb;
   
   char * method;
   char * url;
   char * version;
   //check connection timeout 
   int numchar = get_line(client,buf,sizeof(buf));
   if(numchar==-1)
   {
       discard_remainheaders(client,buf,BUFFSIZE);
       time_out(client);
       (void)close(client);
       return;
   }
   
   //logging the request header
   char temp[1024];
   strcpy(temp,"Request-Header: ");
   strcat(temp,buf);
   int len = strlen(temp);
   temp[len-1] = '\0';
   temp[len-2] = '\n';

   if ( logfd > 0 ){
      write(logfd,temp,strlen(temp));
   }

   //parse the method
   method = strtok(buf," ");
   if(!is_http_method(method))
   {
       if ( logfd > 0 ){
         strcpy(buf,"Status: HTTP/1.0 400 BAD REQUEST\n");
	 write(logfd,buf,strlen(buf));
         strcpy(buf,"Content-Length: 0\n");
         write(logfd,buf,strlen(buf));
       }
       discard_remainheaders(client,buf,BUFFSIZE);
       bad_request(client);
       (void)close(client);
       printf("method = %s*\n",method);
       return;
   }
	
   //check umimplemented
   if( strcasecmp(method,"GET") && strcasecmp(method,"HEAD")){
       if ( logfd > 0 ){
         strcpy(buf,"Status: HTTP/1.0 501 Method Not Implemented\n");
         write(logfd,buf,strlen(buf));
	 strcpy(buf,"Content-Length: 0\n");
         write(logfd,buf,strlen(buf));
       }
       discard_remainheaders(client,buf,BUFFSIZE);
       unimplemented(client);
       (void)close(client);
       return;
   }

   //Parse the url
   url = strtok(NULL," ");
   int type;
   type = parseUrl(url,basepath,swspath,cgi_dir);
   if (type == 1){
      close(client);
      return;
   }
   else{
      url = basepath;
   }
   //parse and check the http version
   version = strtok(NULL," ");
   /*
   if (strlen(version) > = 9 ){
      version[8] = '\0';
   }
   */
   if(version == NULL || !is_valid_version(version))
   {
       if ( logfd > 0 ){
         strcpy(buf,"Status: HTTP/1.0 400 BAD REQUEST\n");
         write(logfd,buf,strlen(buf));
         strcpy(buf,"Content-Length: 0\n");
         write(logfd,buf,strlen(buf));
       }
       discard_remainheaders(client,buf,BUFFSIZE);
       bad_request(client);
       close(client);
       return;
   }	

   
   if (strncasecmp(version, "HTTP/1.0",8))
   { 
       if ( logfd > 0 ){
         strcpy(buf,"Status: HTTP/1.0 400 BAD REQUEST\n");
         write(logfd,buf,strlen(buf));
         strcpy(buf,"Content-Length: 0");
         write(logfd,buf,strlen(buf));
         (void)close(logfd);
       }
       discard_remainheaders(client,buf,BUFFSIZE);
       version_error(client);
       close(client);
       return;
   }
   

   if (  stat(url,&sb) == -1){
       if ( logfd > 0 ){
         strcpy(buf,"Status: HTTP/1.0 404 NOT FOUND\n");
         write(logfd,buf,strlen(buf));
         strcpy(buf,"Content-Length: 0\n");
         write(logfd,buf,strlen(buf));
       }

       discard_remainheaders(client,buf,BUFFSIZE);
       not_found(client);
       close(client);
       return;
   }
   
   if ( logfd > 0 ){
       strcpy(buf,"Status: HTTP/1.0 200 OK\n");
       write(logfd,buf,strlen(buf));
   }

   int dirflag = 0;  
   if ((sb.st_mode & S_IFMT) == S_IFDIR){
      strcpy(path,url);
      strcat(path,"index.html");
      dirflag = 1;
   }
   else if ((sb.st_mode & S_IFMT) == S_IFREG){
      strcpy(path,url);
   }
   
   
   if ( logfd > 0 && stat(path,&sb) != -1 ){
      sprintf(buf,"Content-Length: %d\n",(int)sb.st_size);
      write(logfd,buf,strlen(buf));
   }
   else if(logfd > 0 && stat(url,&sb) != -1 && strcmp(url,path) != 0){
      sprintf(buf,"Content-Length: %d\n",(int)sb.st_size);
      write(logfd,buf,strlen(buf));
   }


   if (strcasecmp(method,"HEAD") == 0){
       discard_remainheaders(client,buf,BUFFSIZE);
       sendheaders(client,path);
       close(client);
       return;
   }

   if ( strcasecmp(method,"GET") == 0){
      
       //if the request url is dir, and no index.html in the dir
       discard_remainheaders(client,buf,BUFFSIZE);
       if ( stat(path,&sb) == -1 && (dirflag == 1) ){
	  send_content(client,url);
       }
       else{
	  send_file(client,path);
       }
   }
   
   close(client);
}

/******************************************************/
/*This function is to clean up the remain headers in one
 *request stored in a socket.
 *After the socket is closed and a new request connet to
 * the same socket, make sure the socket is empty*/
/******************************************************/
int
discard_remainheaders(int client, char *buf, int size){
   int n;
   //consume the remain content in the client socket
   while( (n = recv(client,buf,size,0)) > 0 ){
       //fetched all the remain stuff, otherwise it will fill the buf
       if ( n < BUFFSIZE ){
	  break;
       }
   }

   return 0;
}

	
/******************************************************/
/*This function is to parse the url and check if it is a
 *cgi requst, and conver the espace character in the url
 *and add the basepath to the url
 * execute the cgi if it is a cgi call and return 1
 *create new url and return 2*/
/******************************************************/
int
parseUrl(char * url, char * path, char * swspath, char * cgi_dir){

   //check if it is a cgi
   if (strncmp(url,"/cgi-bin",8) == 0 && strlen(cgi_dir) > 0){
      strcpy(path, cgi_dir);
      strcat(path,url);
      return 1 ;
   }

   //covert the escape character
   char temp[PATH_MAX];
   int i, num = 0, index = 0 ;
   
   //deal with no-leading-slash
   if ( url[0] != '/'){
      temp[index++] = '/';
   }

   for (i = 0 ; i < ((int)strlen(url) - 2) ; ++ i ){
       //check % hex hex 
       if ( url[i] == '%'){
          num = 0 ;
          int flag = 1 ;
          if (url[i+1] >= 48 && url[i+1]<= 57){
             num = num + (url[i+1] - 48) * 16; 
          }
          else if (url[i+1] >= 65 && url[i+1] <= 70){
	     num = num + (url[i+1] - 65 + 10) * 16;
	  }
          else{
	     flag = 0 ;
          }

          if (flag == 1 && url[i+2] >= 48 && url[i+2]<=57){
             num = num + (url[i+2] - 48);
          }
          else if (flag == 1 && url[i+2] >= 65 && url[i+2] <= 70){
             num = num + (url[i+2] - 65 + 10);
          }
          else{
	     num = -1 ;
	  }
          if ( num > 0 ){
	     temp[index++] = (char)num;
             i = i + 2;
             continue;
          }
       }

       temp[index++] = url[i];
   }
   for(; i < strlen(url); ++ i){
       temp[index++] = url[i];
   }
   temp[index] = '\0';
 
   
   //deal with '~'
   if ( strncmp(temp,"/~",2) == 0 ){
      strcpy(path, swspath);

      for( i = 2 ; i < strlen(temp); ++ i ){
	 if ( temp[i] == '/')
	    break;
      }

      int loc = strlen(path);
      for ( ; i < strlen(temp); ++ i ){
          path[loc++] = temp[i];
      }
      path[loc] = '\0';
      printf("url:%s\n",path);
      return 2;
   }

   strcat(path,temp);
   return 2;

}


