#include "http.h"
#include "net.h"
/**********************************************************************/
/* This function check if the http verison is HTTP/1.0 or not*/
/**********************************************************************/

int is_valid_version(char *version_char_array)
{

   if ( strncasecmp(version_char_array,"HTTP/",5) != 0)
	return 0 ; 

   return 1 ;
}

/**********************************************************************/
/* This function check if the method is one of the methods that http 
 * verison HTTP/1.0 supports*/
/**********************************************************************/
int is_http_method(char *method_char_array)
{
	if(!strcasecmp(method_char_array, "GET"))
		return 1;
	if(!strcasecmp(method_char_array, "HEAD"))
        	return 1;
	if(!strcasecmp(method_char_array, "DELETE"))
        	return 1;
	if(!strcasecmp(method_char_array, "CONNECT"))
        	return 1;
	if(!strcasecmp(method_char_array, "OPTIONS"))
        	return 1;
	if(!strcasecmp(method_char_array, "TRACE"))
                return 1;
	if(!strcasecmp(method_char_array, "POST"))
                return 1;
	return 0;
}

/**********************************************************************/
/* This function return the time out reponse */
/**********************************************************************/
void time_out(int client)
{
        char buf[BUFFSIZE];
        sprintf(buf, "HTTP/1.0 408 Request Timeout\r\n");
        send(client, buf, strlen(buf), 0);
        sprintf(buf, "Content-type: text/html\r\n");
        send(client, buf, strlen(buf), 0);
        sprintf(buf, "\r\n");
        send(client, buf, strlen(buf), 0);
        sprintf(buf, "<P> sorry time out</p>");
        send(client, buf, strlen(buf), 0);
        sprintf(buf, "sorry.\r\n");
        send(client, buf, strlen(buf), 0);
}

/**********************************************************************/
/* This function return the bad request reponse, the request should 
 * have format of METHOD url HTTP/version */
/**********************************************************************/
void bad_request(int client)
{       
        char buf[BUFFSIZE];
        sprintf(buf, "HTTP/1.0 400 BAD REQUEST\r\n");
        send(client, buf, strlen(buf), 0);
        sprintf(buf, "Content-type: text/html\r\n");
        send(client, buf, strlen(buf), 0);
        sprintf(buf, "\r\n");
        send(client, buf, strlen(buf), 0);
        sprintf(buf, "<P>Your browser sent a bad request, ");
        send(client, buf, strlen(buf), 0);
        sprintf(buf, "such as a POST without a Content-Length.\r\n");
        send(client, buf, strlen(buf), 0);
}


/**********************************************************************/
/* This function return the version error response */
/**********************************************************************/
void version_error(int client)
{
        char buf[BUFFSIZE];
        sprintf(buf, "HTTP/1.0 505 Version Not Supported\r\n");
        send(client, buf, strlen(buf), 0);
	sprintf(buf, "Server: sws/0.1.0\r\n");
	send(client, buf, strlen(buf), 0);
        sprintf(buf, "Content-type: text/html\r\n");
        send(client, buf, strlen(buf), 0);
        sprintf(buf, "\r\n");
        send(client, buf, strlen(buf), 0);
        sprintf(buf, "<P>HTTP version not supported. HTTP 500\r\n");
        send(client, buf, strlen(buf), 0);
}

/**********************************************************************/
/* Inform the client that the requested web method has not been
 * implemented.
 * Parameter: the client socket */
/**********************************************************************/
void unimplemented(int client){
   char buf[BUFFSIZE];

   sprintf(buf, "HTTP/1.0 501 Method Not Implemented\r\n");
   send(client, buf, strlen(buf), 0);
   sprintf(buf, "Server: sws/0.1.0\r\n");
   send(client, buf, strlen(buf), 0);
   sprintf(buf, "Content-Type: text/html\r\n");
   send(client, buf, strlen(buf), 0);
   sprintf(buf, "\r\n");
   send(client, buf, strlen(buf), 0);
   sprintf(buf, "<HTML><HEAD><TITLE>Method Not Implemented\r\n");
   send(client, buf, strlen(buf), 0);
   sprintf(buf, "</TITLE></HEAD>\r\n");
   send(client, buf, strlen(buf), 0);
   sprintf(buf, "<BODY><P>HTTP request method not supported.\r\n");
   send(client, buf, strlen(buf), 0);
   sprintf(buf, "</BODY></HTML>\r\n");
   send(client, buf, strlen(buf), 0);
}

/**********************************************************************/
/* Give a client a 404 not found status message. */
/**********************************************************************/
void not_found(int client){
   char buf[BUFFSIZE];

   sprintf(buf, "HTTP/1.0 404 NOT FOUND\r\n");
   send(client, buf, strlen(buf), 0);
   sprintf(buf, "Server: sws/0.1.0\r\n");
   send(client, buf, strlen(buf), 0);
   sprintf(buf, "Content-Type: text/html\r\n");
   send(client, buf, strlen(buf), 0);
   sprintf(buf, "\r\n");
   send(client, buf, strlen(buf), 0);
   sprintf(buf, "<HTML><TITLE>Not Found</TITLE>\r\n");
   send(client, buf, strlen(buf), 0);
   sprintf(buf, "<BODY><P>The server could not fulfill\r\n");
   send(client, buf, strlen(buf), 0);
   sprintf(buf, "your request because the resource specified\r\n");
   send(client, buf, strlen(buf), 0);
   sprintf(buf, "is unavailable or nonexistent.\r\n");
   send(client, buf, strlen(buf), 0);
   sprintf(buf, "</BODY></HTML>\r\n");
   send(client, buf, strlen(buf), 0);
}

/**********************************************************************/
/*Send a regular file to client if system error happens
 *return not found and log the error to stdout or logfile*/
/**********************************************************************/
void send_file(int client, char *filename){
 
   FILE * file = NULL ;
   file = fopen(filename,"r");
   if ( file == NULL ){
      //if the permission denied, we assume the file is not avaible,
      //regard this situation as not found the file
      not_found(client);
      fprintf(stderr,"cannot open %s : %s\n",filename,strerror(errno));
      return;
   }
   
   sendheaders(client,filename);
   transport2(client,file); 
}

/**********************************************************************/
/*Send all the entries under a directory file
 *return not found and log the error to stdout or logfile*/
/**********************************************************************/
void send_content(int client, char * filename){
   
   char buf[BUFFSIZE];
   sendheaders(client,filename);

   int i;
   char ** entry;
   int entrycount = 0 ;
   if ( (entry=getentryinpath(filename,&entrycount)) == NULL){
        return;
   }
   else{
       entrysort(entry,entrycount);
       sprintf(buf, "<HTML><TITLE>Content</TITLE>\r\n");
       send(client, buf, strlen(buf), 0);
       sprintf(buf, "<BODY><P>The content in %s<br>\r\n",filename);
       send(client, buf, strlen(buf), 0);
       for( i = 0 ; i < entrycount; ++ i ){
          if ( entry[i][0] == '.')
	     continue;
	  sprintf(buf, "%s<br>\r\n",entry[i]);
          send(client, buf, strlen(buf), 0);
       } 
       sprintf(buf, "</BODY></HTML>\r\n");
       send(client, buf, strlen(buf), 0);
       free(entry);
   }
}

/**********************************************************************/
/*transport the content of the file to the client */
/**********************************************************************/
void transport(int client, FILE *resource){
   char buf[BUFFSIZE];
   errno = 0 ;
   fgets(buf, sizeof(buf), resource);
   while (!feof(resource)){
       send(client, buf, strlen(buf), 0);
       fgets(buf, sizeof(buf), resource);
   }

   if ( errno != 0 ){
     fprintf(stderr,"transport file error : %s\n",strerror(errno));
   }
   (void)fclose(resource);
}

/**********************************************************************/
/*Another function to send the file to client, and it will not involves
 *'\0' each time, read the content from the file*/
/**********************************************************************/
void transportBinary(int client, FILE *resource){
   char buf[MAXLEN];
   int fd = fileno(resource);
   struct stat sb ;
   if ( fd == -1 || fstat(fd,&sb) < 0 ){
      return ;
   }

   fread(buf,sizeof(char), sb.st_size+1, resource);
   (void)fclose(resource);
   send(client, buf, sb.st_size, 0);
}

void transport2(int client, FILE * resource){
   int fd = fileno(resource);
   struct stat sb ;
   if ( fd == -1 || fstat(fd,&sb) < 0 ){
      return ;
   }

   int n ;
   char buf[BUFFSIZE];
   while ( (n = fread(buf, sizeof(char), BUFFSIZE, resource)) > 0){
      send(client,buf, n, 0);
   }

   if ( ferror(resource) != 0){
      fprintf(stderr,"transport file error : %s\n",strerror(errno));     
   }

   (void)fclose(resource);
}



/**********************************************************************/
/* Return the informational HTTP headers about a file. */
/* Parameters: the socket to print the headers on
 *             the name of the file */
/**********************************************************************/
void sendheaders(int client, char *filename){
   char buf[BUFFSIZE];
   char filetype[BUFFSIZE];
    
   struct stat sb;
   struct tm * temp;
   time_t ct;

   //status
   strcpy(buf, "HTTP/1.0 200 OK\r\n");
   send(client, buf, strlen(buf), 0);
   
   //current Date
   strcpy(buf,"Date: ");
   time(&ct);
   temp = gmtime(&ct);
   getgmt(buf,temp);
   send(client, buf, strlen(buf), 0);   

   //server name
   strcpy(buf, "Server: sws/0.1.0\r\n");
   send(client, buf, strlen(buf), 0);

   //file last modified time
   if ( stat(filename, &sb) == -1){
      fprintf(stderr,"cannot stat : %s\n",strerror(errno));
   }
   else{
      strcpy(buf,"Last-Modified: ");
      temp = localtime(&sb.st_mtime);
      getgmt(buf,temp);
      send(client, buf, strlen(buf), 0);
   }
   
   //file type
   checkfiletype(filename,filetype);
   sprintf(buf, "%s",filetype); 
   send(client, buf, strlen(buf), 0);

   //file length (byte)
   if ( stat(filename, &sb) == -1){
      fprintf(stderr,"cannot stat : %s\n",strerror(errno));
   }
   else if ((sb.st_mode & S_IFMT) == S_IFREG){
      sprintf(buf,"Content-Length: %d\r\n",(int)sb.st_size);
      send(client, buf, strlen(buf), 0);
   }
   strcpy(buf, "\r\n");
   send(client, buf, strlen(buf), 0);
}

void getgmt(char * buf, struct tm* temp){
   char ftime[30];
   strftime(ftime,30,"%a, ",temp);
   strcat(buf,ftime);
   strftime(ftime,30,"%d ",temp);
   strcat(buf,ftime);
   strftime(ftime,30,"%b ",temp);
   strcat(buf,ftime);
   strftime(ftime,30,"%G ",temp);
   strcat(buf,ftime);
   strftime(ftime,30,"%H:",temp);
   strcat(buf,ftime);
   strftime(ftime,30,"%M:",temp);
   strcat(buf,ftime);
   strftime(ftime,30,"%S GMT\r\n",temp);
   strcat(buf,ftime);
}

/**********************************************************************/
/*This function is to determine the file type of the request content*/
/**********************************************************************/
void checkfiletype(char * filename, char * filetype){
   
   const char * magic_full;
   magic_t magic_cookie;
   magic_cookie = magic_open(MAGIC_MIME);
   if ( magic_cookie == NULL ){
      fprintf(stderr,"unable to initialize magic libarary : %s\n",
							strerror(errno));
      strcpy(filetype,"Content-Type: text/html\r\n");
      return;
   }

   if ( magic_load(magic_cookie,NULL) != 0){
      fprintf(stderr,"cannot to load magic database -: %s\n",
                                               magic_error(magic_cookie));
      strcpy(filetype,"Content-Type: text/html\r\n");
      magic_close(magic_cookie);
      return;
   }
   
   if ( (magic_full = magic_file(magic_cookie,filename)) == NULL){
      fprintf(stderr,"cannot magic_file: %s\n",strerror(errno));
      strcpy(filetype,"Content-Type: text/html\r\n");
      magic_close(magic_cookie);
      return;
   } 

   //if the request is a directory, return a html file to show the entries in
   //the diretory.
   if ( strcmp(magic_full,"inode/directory; charset=binary") == 0 ){
      strcpy(filetype,"Content-Type: text/html\r\n");
      magic_close(magic_cookie);
      return;
   }

   strcpy(filetype,"Content-Type: ");
   strcat(filetype, magic_full);
   strcat(filetype, "\r\n");

   //printf("magic_full:%s\n", magic_full);
   return;
}

char **
getentryinpath(char * pathname, int * count){
  DIR *dp ;
  int entrycount = 0 ;
  if ( (dp = opendir(pathname)) == NULL ){
        fprintf(stderr, "ls(1): can't access %s : %s\n", pathname,
                                                        strerror(errno));
        (void)closedir(dp);
        return NULL;
  }
  struct dirent *dirp;
  int max_len = 0 ;
  while ((dirp = readdir(dp)) != NULL){
     if ( strlen(dirp->d_name) > max_len)
           max_len = strlen(dirp->d_name) + 1 ;
     entrycount++;
  }
  if ( closedir(dp) == -1 )
        fprintf(stderr,"closedir failed %s\n",strerror(errno));

  //record the entries in this pathname
  if ( (dp = opendir(pathname)) == NULL ){
        fprintf(stderr, "ls(1): can't access %s : %s\n", pathname,
                                                        strerror(errno));
        (void)closedir(dp);
        return NULL;
  }

  //record the entry number
  *count = entrycount;
  char **entry = NULL;
  if (( entry = malloc(entrycount*sizeof(char*))) == NULL ){
        fprintf(stderr, "ls(1): can't malloc: %s\n",strerror(errno));
        return NULL;
  }

  int i = 0 ;
  while ((dirp = readdir(dp)) != NULL){
        //max_len + 1, here +1 for the option -F,space for special char
        if (( entry[i] = malloc(max_len+1)) == NULL){
           fprintf(stderr, "ls(1): can't malloc: %s\n",strerror(errno));
           freechararray(entry,i);
           return NULL;
        }
        strcpy(entry[i],dirp->d_name);
        i ++ ;
  }
  return entry;
}

void
entrysort(char ** entry, int entrynum){
  char temp[PATH_MAX+1];
  //switch Sort
  int i, j;
  for (i = 0 ; i < entrynum-1 ; ++ i)
      for ( j = i+1 ; j < entrynum ; ++j ){
          if ( strcmp(entry[i],entry[j]) > 0 ){
             strcpy(temp,entry[i]);
             strcpy(entry[i],entry[j]);
             strcpy(entry[j], temp);
          }
      }
}


//memory free
void
freechararray(char ** entry, int n){
   int i;
   for ( i = 0 ; i < n ; ++ i){
       free(entry[i]);
   }
   free(entry);
}
