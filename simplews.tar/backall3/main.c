#include <stdlib.h>
#include <sys/types.h>
#include <dirent.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <limits.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/stat.h>
#include <fcntl.h>

#include "net.h"
#include "http.h"
#ifndef OPTION_NUM //the total number of the options for sws(1)
#define OPTION_NUM 6
#endif

char options[OPTION_NUM];
char cgi_dir[PATH_MAX]; //store the dir pathname
char log_file[PATH_MAX]; //store the logfile pathname
struct sockaddr_in6 ipv6server;
struct sockaddr_in server;
char basepath[PATH_MAX];
/******************************************************/
/* To check the options set by user
 * Setup the cgi dir, debug mode, and etc.
 * Print usage summary and exit
 * Otherwise return port number; */
/*******************************************************/
int
checkoptions(int argc, char ** argv );

int
main(int argc, char ** argv){
   
  int  port;
  port = checkoptions(argc,argv);

  char swspath[PATH_MAX];
  realpath(argv[0],swspath);
  if ( swspath == NULL ){
     fprintf(stderr,"fail to get server path: %s\n",strerror(errno));
     exit(EXIT_FAILURE);
  }

  int client_sock1 = -1, client_sock2 = -1;
  struct sockaddr_in client_name;
  struct sockaddr_in peer_name;
  socklen_t clientname_len = sizeof(client_name);
  socklen_t peer_len = sizeof(peer_name);

  int server_sock1 = -1, server_sock2 = -1;
  char buf[1024];

  //Start the server with -i option and Bind to ipv4 address 
  if ( options[3] == 4 ){
     server_sock1 = startup1(&port,options,&server);
  }
  //Bind to ipv6 address,since sockaddr_in6 also support ipv4 adrress,so when
  //options[3]=0 or options[3]=6,it will support both ipv4 and ipv6 address
  else{
     server_sock2 = startup2(&port,options,&ipv6server);
  }
  printf("sws running on port %d\n", port);
  
  int logfd  = -1;
  if (options[4] == 'l'){
      if ( (logfd = open(log_file, O_WRONLY | O_APPEND)) == -1){
           fprintf(stderr,"cannot open file %s for log: %s\n",
                                                     log_file ,strerror(errno));
      }
  }
  while(1){
     //-i option is set and bind to an ipv4 address 
     if ( options[3] == 4){
	client_sock1 = accept(server_sock1,(struct sockaddr *)&client_name,
							&clientname_len);
        if ( client_sock1 == -1 ){
            fprintf(stderr,"accept request fail: %s\n",strerror(errno));
	    continue;
        }

        if  ( logfd > 0 ){
           if ( getpeername(client_sock1,(struct sockaddr *)&peer_name,
                                                        &peer_len) == 0 ){
	       sprintf(buf,"Remote-IP: %s\n",inet_ntoa(peer_name.sin_addr));
               if ( write(logfd,buf,strlen(buf)) == -1){
                    fprintf(stderr,"cannot write to %s : %s\n",
                                                   log_file,strerror(errno));
               }
           }
           else{
               fprintf(stderr,"cannot getpeerame: %s\n",strerror(errno));
	   }

           struct tm * temp;
           time_t ct;
           time(&ct);
           temp = gmtime(&ct);
           strcpy(buf,"Received-Time: ");
           getgmt(buf,temp);
           //change '\r\n' to '\n\0'
           int len = strlen(buf);
           buf[len-1] = '\0';
           buf[len-2] = '\n';
        
           if ( write(logfd,buf,strlen(buf)) == -1){
                fprintf(stderr,"cannot write to %s : %s\n",
                                                  log_file,strerror(errno));
           }
        }

	struct timeval timeout = {20,0};
        int ret = setsockopt(client_sock1,SOL_SOCKET,SO_RCVTIMEO,&timeout,
							sizeof(timeout));
	if( ret == -1){
            printf("log set timeout failed\n");
        }

	send_response(client_sock1,logfd,basepath,options,cgi_dir,swspath);
        if ( logfd > 0){
           strcpy(buf,"--------------\n");
           if ( write(logfd,buf,strlen(buf)) == -1){
               fprintf(stderr,"cannot write to %s : %s\n",
                                                   log_file,strerror(errno));
           }
        }
        
     }
     else{
 	client_sock2 = accept(server_sock2,(struct sockaddr *)&client_name,
							&clientname_len);
        if ( client_sock2 == -1){
           fprintf(stderr,"cannot accept %s\n",strerror(errno));
           continue;
        }

        if  ( logfd > 0 ){
	   if ( getpeername(client_sock2,(struct sockaddr *)&peer_name,
                                                        &peer_len) == 0 ){
               char buf[1024];
               sprintf(buf,"Remote-IP: %s\n",inet_ntoa(peer_name.sin_addr));
               if ( write(logfd,buf,strlen(buf)) == -1){
                   fprintf(stderr,"cannot write to %s : %s\n",
                                                   log_file,strerror(errno));
               }

           }
           else{
               fprintf(stderr,"cannot getpeerame: %s\n",strerror(errno));
	   }

	   struct tm * temp;
           time_t ct;
           time(&ct);
           temp = gmtime(&ct);
           strcpy(buf,"Received-Time: ");
           getgmt(buf,temp);
	   //change '\r\n' to '\n\0'
           int len = strlen(buf);
           buf[len-1] = '\0';
           buf[len-2] = '\n';

           if ( write(logfd,buf,strlen(buf)) == -1){
                fprintf(stderr,"cannot write to %s : %s\n",
                                                  log_file,strerror(errno));
           }

	} 

        //printf("before send the client = %d\n", client_sock2); 
	struct timeval timeout = {20,0};
        int ret = setsockopt(client_sock2,SOL_SOCKET,SO_RCVTIMEO,&timeout,
                                                   sizeof(timeout));
        if( ret == -1){
            printf("log set timeout failed\n");
        }
         
	send_response(client_sock2,logfd, basepath, options,cgi_dir,swspath);
        if (logfd > 0 ){
           strcpy(buf,"--------------\n");
           if ( write(logfd,buf,strlen(buf)) == -1){
               fprintf(stderr,"cannot write to %s : %s\n",
                                                   log_file,strerror(errno));
           }
        }

        //printf("after send the client = %d\n", client_sock2);
     }

  }
  (void)close(server_sock1);
  (void)close(server_sock2);
  //The folloing is to test some functions
  /*
  //test -p
  printf("port = %d\n",port);
  //test -c
  printf("cgi_dir = %s\n", cgi_dir);
  //test -l
  printf("logfile = %s\n", log_file);
  //test -i
  printf("ipv4 adrr = %d\n",server.sin_addr.s_addr);
  int i ;
  printf("ipv6 adrr = ");
  for ( i = 0 ; i < 16 ; i ++)
     printf("%d:",ipv6server.sin6_addr.s6_addr[i]);
  printf("\n");
  */

  /*
  printf("ipv4 adrr = %d\n",server.sin_addr.s_addr);
  
  startup1(&port, options, &server);
  printf("Socket has port #%d\n", ntohs(server.sin_port));
  printf("ipv4 adrr = %d\n",server.sin_addr.s_addr);
  //startup2(&port, options, &ipv6server);
  */

  exit(0);

}



int
checkoptions(int argc, char ** argv ){
    
    //check the options
    mode_t mode;
    mode = (S_IRWXU | S_IRWXG | S_IRWXO);

    char ch;
    int logfd = -1 ;
    char * ptr;
    int port = 8080 ;
    while (( ch = getopt(argc,argv,"c:dhi:l:p:")) != -1 ){
        switch(ch){
	   case 'c' :
	         if ( opendir(optarg) == NULL ){
		    fprintf(stderr,"cannot opendir %s : %s\n", optarg,
							     strerror(errno));
		    exit(EXIT_FAILURE);
		 }
		 
		 if ( strlen(optarg) < PATH_MAX){
		    strcpy(cgi_dir,optarg);
		    options[0] = 'c';
		 }
		 else{
		    fprintf(stderr,"dir %s exceeds PATH_MAX\n", optarg);
		    exit(EXIT_FAILURE);
		 }
		 break;
	   case 'd' :
	    	 options[1] = 'd';
		 break;
	   case 'h' :
		 printf("sws [−dh] [−c dir] [−i address] [−l file]%s", 
						         " [−p port] dir\n");
	         exit(0);
	   case 'i' :
		/* options[3] = 0,listen to all the ip address
  		 * options[3] = 4,listen to ipv4
     		 * options[3] = 6,listen to ipv6
    	 	*/
		if(inet_pton(AF_INET,optarg,(void*)&server.sin_addr.s_addr)==1){
		    options[3] = 4 ;
		} 
		else if( inet_pton(AF_INET6,optarg,
				(void*)&ipv6server.sin6_addr.s6_addr)==1){
		    options[3] = 6 ;
		}
		else{
		    fprintf(stderr,"the address %s is not valid\n", optarg);
		    exit(EXIT_FAILURE);
		}
		break;
	   case 'l' :
		if ( (logfd = open(optarg, O_WRONLY | O_CREAT | O_APPEND,
								mode)) == -1){
		    fprintf(stderr,"cannot open file %s for log: %s\n",
					             optarg ,strerror(errno));
		    exit(EXIT_FAILURE);
		}

		if ( strlen(optarg) < PATH_MAX){
                    strcpy(log_file,optarg);
                    options[4] = 'l';
                    (void)close(logfd);
                }
		else{
                    printf("file %s exceeds PATH_MAX\n", optarg);
                    exit(EXIT_FAILURE);
                }
		break;
	   case 'p' :
 		port = strtol(optarg,&ptr,10);
		if ( port < 0 || port > 65535 ){
		    printf("port %s is not valid\n", optarg);
		    exit(EXIT_FAILURE);
		}
		options[5] = 'p';
	}
    }

    //argc -= optind;
    //argv += optind;
    if ( argv[optind] == NULL ){
       printf("sws [−dh] [−c dir] [−i address] [−l file]%s",
                                                         " [−p port] dir\n");
       exit(EXIT_FAILURE);
    }
    strcpy(basepath,argv[optind]);
    int loc = (int)strlen(basepath);
    if ( basepath[loc-1] == '/'){
         basepath[loc-1] = '\0';
    }

    return port;
}
