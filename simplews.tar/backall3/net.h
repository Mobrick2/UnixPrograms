#ifndef _NET_H
#define _NET_H

#include <stdlib.h>
#include <sys/types.h>
#include <dirent.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <limits.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <ctype.h>
#include <magic.h>

#ifndef MAX_COLLECTIONS
#define MAX_COLLECTIONS 10
#endif

#ifndef BUFFSIZE
#define BUFFSIZE 1024
#endif


int 
startup1( int *port, char * options, struct sockaddr_in *server);

int 
startup2( int *port, char * options, struct sockaddr_in6 *server);

int
discard_remainheaders(int client, char *buf, int size);

int
get_line(int client, char *buf, int size);

void
send_response(int client, int logfd, char * basepath, 
		char * options, char * cgi_dir, char *swspath);

int
parseUrl(char * url, char * path, char *swspath, char * cgi_dir);

#endif
