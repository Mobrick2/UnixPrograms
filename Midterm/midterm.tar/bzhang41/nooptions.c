#include "myfun.h"
#include "nooptions.h"
void lsnoflags(int argc, char** argv, int argcc){
  //If argcc = 0, display the entries in current directory
  if ( 0 == argcc ){
     //show the entries in the current director, 1 means one
     //operand, since no operand input means current dir.
     showentryindir(".",1);   
     exit(EX_OK);
  }

  //argcc > 0, we have several operands
  
  char **direntry;
  int dirc = 0 ;
  if (( direntry = malloc(argcc*sizeof(char*))) == NULL ){
        fprintf(stderr, "ls(1): can't malloc: %s\n",strerror(errno));
        exit(EXIT_FAILURE);
  }
  char **notdirentry;
  int notdirc = 0 ;
  if (( notdirentry = malloc(argcc*sizeof(char*))) == NULL ){
        fprintf(stderr, "ls(1): can't malloc: %s\n",strerror(errno));
        exit(EXIT_FAILURE);
  }
  

  int index, type;
  //Separate directory operands and not non-dir operands
  for ( index = optind; index < argc; index++){
     type = checkfiletype(argv[index]) ;
     //printf("type is %d\n", type);
     if ( type == 1){
        if (( direntry[dirc] = malloc(PATH_MAX)) == NULL){
	   fprintf(stderr, "ls(1): can't malloc: %s\n",strerror(errno));
           exit(EXIT_FAILURE);
	}
        strcpy(direntry[dirc],argv[index]);
        //printf("type is %s\n", direntry[dirc]);
        dirc++;        
     }      
     else if(type >= 0 && type != 1){
        if (( notdirentry[notdirc] = malloc(PATH_MAX)) == NULL){
           fprintf(stderr, "ls(1): can't malloc: %s\n",strerror(errno));
           exit(EXIT_FAILURE);
        }
        strcpy(notdirentry[notdirc],argv[index]);
	//printf("type is %s\n", notdirentry[notdirc]);
        notdirc++;
     }
  }
  //sort and display separately
  (void) entrysort(notdirentry,notdirc);
  entrydisplay(notdirentry,notdirc,0);
  if ( notdirc > 0 && dirc > 0)
     printf("\n");
  
  int i;
  (void) direntrysort(direntry,dirc);
  for ( i = 0 ; i < dirc ; ++ i){
    showentryindir(direntry[i],dirc);
    if ( i < dirc - 1 )
       printf("\n");
  }
}

