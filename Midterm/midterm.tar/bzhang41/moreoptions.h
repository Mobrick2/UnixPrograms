#ifndef _MOREOPTIONS_H
#define _MOREOPTIONS_H

#include <unistd.h>
#include <err.h>
#include <stdio.h>
#include <locale.h>
#include <libgen.h>
#include <sys/param.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <bsd/string.h>
#include <sysexits.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <pwd.h>
#include <grp.h>
#include <linux/kdev_t.h>
#include <time.h>
#include <limits.h>
#include <fts.h>

#ifndef PATH_MAX
#define PATH_MAX 256
#endif

void
lsmoreflags(int argc,char **argv, char *flags, int argcc, int flagsc);


void displaywithmoreoptions(char * pathname, char * options);


void
coldisplaywithserialnumber(char ** entry, int entrycount, int style);

void
displayserialbyloc(char ** entry, int entrycount, int index,
                int maxlen, int style);

int
findseriallen(char ** entry, int entrycount,int loc, int style);

int
findmaxserialnumlen(char **entry,int entrycount,int style);

void recursivecoldisplayinpath(char * const *path, char * pathname,
                                char * option, int style);

int
comparename2(const FTSENT ** one, const FTSENT** two);

void
coldisplaywithoutexit(char ** entry, int entrycount, int style);

int
findmaxsizenumlen(char **entry,int entrycount,int style);

void
ctimesortwithpathname(char* pathname, char** entry, int entrycount);
#endif

