#include "myfun.h"

#ifndef OPTION_NUM //the total number of the options
#define OPTION_NUM 125
#endif

char **
getentryinpath(char * pathname, int *count){
  DIR *dp ;
  int entrycount = 0 ;
  if ( (dp = opendir(pathname)) == NULL ){
        fprintf(stderr, "ls(1): can't access %s : %s\n", pathname,
                                                        strerror(errno));
        (void)closedir(dp);
        return NULL;
  }
  struct dirent *dirp;
  int max_len = 0 ;
  while ((dirp = readdir(dp)) != NULL){
     if ( strlen(dirp->d_name) > max_len)
           max_len = strlen(dirp->d_name) + 1 ;
     entrycount ++ ;
  }
  if ( closedir(dp) == -1 )
        fprintf(stderr,"closedir failed %s\n",strerror(errno));
  
  //record the entries in this pathname
  if ( (dp = opendir(pathname)) == NULL ){
        fprintf(stderr, "ls(1): can't access %s : %s\n", pathname,
                                                        strerror(errno));
        (void)closedir(dp);
        return NULL;
  }
  
  //record the entry number
  *count = entrycount;
  char **entry = NULL;
  if (( entry = malloc(entrycount*sizeof(char*))) == NULL ){
        fprintf(stderr, "ls(1): can't malloc: %s\n",strerror(errno));
        return NULL;
  }
  
  int i = 0 ;
  while ((dirp = readdir(dp)) != NULL){
	//max_len + 1, here +1 for the option -F,space for special char
        if (( entry[i] = malloc(max_len+1)) == NULL){
           fprintf(stderr, "ls(1): can't malloc: %s\n",strerror(errno));
           freechararray(entry,i);
           return NULL;
        }
        strcpy(entry[i],dirp->d_name);
        i ++ ;
  }
  return entry;
}

 /*display the entry in one directory
  *The argcc count the number of input operands which
  *indicates how to display multiple operands
  */
void
showentryindir(char * pathname, int argcc){
  
  int entrycount = 0 ;
  char ** entry;
  entry = getentryinpath(pathname,&entrycount);

  if ( entry != NULL ){
     entrysort(entry,entrycount);
     if ( argcc > 1 ){
        printf("%s:\n", pathname);
     }
     /*The third argument means the display style : 0 means don't show file
      *start with .
      */
     entrydisplay(entry,entrycount,0);
     freechararray(entry,entrycount);
  }
}

//memory free
void
freechararray(char ** entry, int n){
   int i;
   for ( i = 0 ; i < n ; ++ i){
       free(entry[i]);
   }
   free(entry);
}


  /*sort the directory entry, since the entry could be a 
   *path, so we need first get it's basename to compare
   *the entry is sorted by their basename
   */
void
direntrysort(char ** direntry,int dirc){
  char temp[PATH_MAX+1];
  //switch Sort
  int i, j;
  for (i = 0 ; i < dirc-1 ; ++ i)
      for ( j = i+1 ; j < dirc ; ++j ){
          if ( strcmp( basename(direntry[i]),basename(direntry[j])) > 0 ){
             strcpy(temp,direntry[i]);
             strcpy(direntry[i],direntry[j]);
             strcpy(direntry[j], temp);
          }
      }
}

/***************************************************
 *display the filenames in entry
 *style = 0 , don't display the files start with .
 ***************************************************
 */
void
entrydisplay(char **entry, int entrycount, int style){
  int i;
  if ( style == 0 ){
     entrysort(entry,entrycount);
     for ( i = 0 ; i < entrycount; ++ i){
	 if ( *entry[i] != '.')
	    printf("%s\n",entry[i]);
     }
  }
  //option -A
  if ( style == 1 ){
     entrysort(entry,entrycount);  
     for ( i = 0 ; i < entrycount ; ++ i)
	if ( strcmp(".", entry[i]) != 0 && strcmp("..", entry[i]) != 0)
	    printf("%s\n",entry[i]);
  }
  
  //option -a 
  if ( style == 2){
     entrysort(entry,entrycount);  
     for ( i = 0 ; i < entrycount ; ++ i)
        printf("%s\n",entry[i]);
  }
  
  //option -l
  if ( style == 11 ){
     entrysort(entry,entrycount);  
     (void) lfdisplay(entry,entrycount,0); 
  }
    
  //option -c
  if ( style == 3){
     (void) ctimedisplay(entry,entrycount,0);
  }
  
  //option -C
  if ( style == 4){
     entrysort(entry,entrycount);  
     (void) coldisplay(entry,entrycount,0);
  }

  //option -F
  if ( style == 6){
     entrysort(entry,entrycount);  
     (void) specialchardisplay(entry,entrycount,0);
  }
 
  //option -f
  if ( style == 7){
     (void) unsorteddisplay(entry,entrycount,0);
  }

  //option -i
  if ( style == 9){
     entrysort(entry,entrycount);
     (void) serialdisplay(entry,entrycount,0);
  }
  
  //option -n
  if ( style == 12){
     entrysort(entry,entrycount);
     //`1` means :
     //same as long format output excepet the group and user name
     (void) lfdisplay(entry,entrycount,1);
  }

  //option -r
  if ( style == 15){
     entrysort(entry,entrycount);
     for ( i = entrycount-1 ; i >= 0 ; -- i){
         if ( *entry[i] != '.')
            printf("%s\n",entry[i]);
     }
  }

  //option -S
  if ( style == 16){
     entrysizesort(entry,entrycount);
     for ( i = 0 ; i < entrycount ; ++ i){
         if ( *entry[i] != '.')
            printf("%s\n",entry[i]);
     }
  }
  //option -s
  if ( style == 17){
     entrysort(entry,entrycount);
     (void)sizedisplay(entry,entrycount,0);     
  }
  //option -t
  if ( style == 18){
     entrysort(entry,entrycount);
     (void)modifiedtimedisplay(entry,entrycount,0);
  }
  //option -u
  if ( style == 19){
     entrysort(entry,entrycount);
     (void)accesstimedisplay(entry,entrycount,0);
  }
}

void
accesstimedisplay(char ** entry, int entrycount, int style){
   int i;
   (void)accesstimesort(entry,entrycount);

   if ( style == 0 ){
      for ( i = 0 ; i < entrycount; ++ i){
          if ( *entry[i]!= '.'){
             printf("%s\n", entry[i]);
          }
      }

   }
}

void
modifiedtimedisplay(char ** entry, int entrycount, int style){
   int i;
   (void)modifiedtimesort(entry,entrycount);
   
   if ( style == 0 ){
      for ( i = 0 ; i < entrycount; ++ i){
          if ( *entry[i]!= '.'){
	     printf("%s\n", entry[i]);
	  }
      }

   }

}

void
accesstimesort(char ** entry, int entrycount){
 char temp[PATH_MAX+1];
  //switch Sort
  int i, j;
  for (i = 0 ; i < entrycount ; ++ i){
      struct stat buf1;
      if ( lstat(entry[i],&buf1) == -1){
         fprintf(stderr,"can't stat %s:%s\n",entry[i],strerror(errno));
         freechararray(entry,entrycount);
         exit(EXIT_FAILURE);
      }
      double cur_max = (double)buf1.st_atim.tv_sec;
      for ( j = i+1 ; j < entrycount ; ++j ){
          struct stat buf2;
          if ( lstat(entry[j],&buf2) == -1){
             fprintf(stderr,"can't stat %s:%s\n",entry[j],strerror(errno));
             freechararray(entry,entrycount);
             exit(EXIT_FAILURE);
          }
          //double temp = difftime(buf1.st_ctim.tv_sec,buf2.st_ctim.tv_sec);
          double candidate = (double)buf2.st_atim.tv_sec;
          if ( candidate > cur_max ){
             strcpy(temp,entry[i]);
             strcpy(entry[i],entry[j]);
             strcpy(entry[j], temp);
             cur_max = candidate;
          }
      }
  }
}

void
modifiedtimesort(char ** entry, int entrycount){
 char temp[PATH_MAX+1];
  //switch Sort
  int i, j;
  for (i = 0 ; i < entrycount ; ++ i){
      struct stat buf1;
      if ( lstat(entry[i],&buf1) == -1){
         fprintf(stderr,"can't stat %s:%s\n",entry[i],strerror(errno));
         freechararray(entry,entrycount);
         exit(EXIT_FAILURE);
      }
      double cur_max = (double)buf1.st_mtim.tv_sec;
      for ( j = i+1 ; j < entrycount ; ++j ){
          struct stat buf2;
          if ( lstat(entry[j],&buf2) == -1){
             fprintf(stderr,"can't stat %s:%s\n",entry[j],strerror(errno));
             freechararray(entry,entrycount);
             exit(EXIT_FAILURE);
          }
          //double temp = difftime(buf1.st_ctim.tv_sec,buf2.st_ctim.tv_sec);
          double candidate = (double)buf2.st_mtim.tv_sec;
          if ( candidate > cur_max ){
             strcpy(temp,entry[i]);
             strcpy(entry[i],entry[j]);
             strcpy(entry[j], temp);
             cur_max = candidate;
          }
      }
  }
}

void
sizedisplay(char ** entry, int entrycount, int style){
  int i, blocksize = 512;
  char *bs;
  char *ptr;
  if ( (bs = getenv("BLOCKSIZE")) !=NULL){
      long bs_temp;
      bs_temp = strtol(bs,&ptr,10);
      if (  (bs_temp > (long)0) && (bs_temp <= (long)INT_MAX) ){
         blocksize = (int)bs_temp;
      }
  }
  int  max = 0;
  if ( style == 0 ){ 
     for ( i = 0 ; i < entrycount; ++ i ){
	 if ( *entry[i] != '.'){
            struct stat buf;
            if ( lstat(entry[i],&buf) == -1){
                fprintf(stderr,"can't stat %s:%s\n",entry[i],strerror(errno));
                freechararray(entry,entrycount);
                exit(EXIT_FAILURE);
            }
 	    int temp = (int)buf.st_blocks*512/blocksize;
            if (temp > max){
		max = temp ;
	    }
	 }
     }

  }

  max = checklenofnum(max);
  if ( style == 0 ){
     for ( i = 0 ; i < entrycount; ++ i ){
         if ( *entry[i] != '.'){
            struct stat buf;
            if ( lstat(entry[i],&buf) == -1){
                fprintf(stderr,"can't stat %s:%s\n",entry[i],strerror(errno));
                freechararray(entry,entrycount);
                exit(EXIT_FAILURE);
            }
            int j;
	    int temp =checklenofnum ((int)buf.st_blocks*512/blocksize);
	    for ( j = 0 ; j < (max-temp); ++ j){
		printf(" ");
	    }
            printf("%ld %s\n",(long)(buf.st_blocks*512/blocksize),entry[i]);
         }
     }

  }
}

void
entrysizesort(char ** entry, int entrycount){
  char temp[PATH_MAX+1];
  //switch Sort
  int i, j;
  for (i = 0 ; i < entrycount ; ++ i){
      struct stat buf1;
      if ( lstat(entry[i],&buf1) == -1){
         fprintf(stderr,"can't stat %s:%s\n",entry[i],strerror(errno));
         freechararray(entry,entrycount);
         exit(EXIT_FAILURE);
      }
      int cur_max = (int)buf1.st_size;
      for ( j = i+1 ; j < entrycount ; ++j ){
          struct stat buf2;
          if ( lstat(entry[j],&buf2) == -1){
             fprintf(stderr,"can't stat %s:%s\n",entry[j],strerror(errno));
             freechararray(entry,entrycount);
             exit(EXIT_FAILURE);
          }

          int candidate = (int)buf2.st_size;
          if ( candidate > cur_max ){
             strcpy(temp,entry[i]);
             strcpy(entry[i],entry[j]);
             strcpy(entry[j], temp);
             cur_max = candidate;
          }
      }
  }
}

void
serialdisplay(char ** entry, int entrycount, int style){
  int i;
  if ( style == 0 ){ 
    for ( i = 0 ; i < entrycount; ++ i ){
	if( *entry[i] != '.'){
           struct stat buf;
           if (lstat(entry[i],&buf) == -1){
               fprintf(stderr,"can't stat %s:%s\n",entry[i],strerror(errno));
               freechararray(entry,entrycount);
               exit(EXIT_FAILURE);
           }
           printf("%d %s\n",(int)buf.st_ino,entry[i]);
        }
     }
  }

}

void
unsorteddisplay(char ** entry, int entrycount, int style){
  int i;
  if( style == 0 ){
    for ( i = 0 ; i < entrycount; ++ i ){
       if ( *entry[i] != '.' )
	  printf("%s\n",entry[i]);
    }
  }

}

int
appendspecialchartoentry(char ** entry, int entrycount){
  int i;
  for ( i = 0 ; i < entrycount; ++ i){
     struct stat buf;
     if (lstat(entry[i],&buf) == -1){
        fprintf(stderr,"can't stat %s:%s\n",entry[i],strerror(errno));
        freechararray(entry,entrycount);
        return -1 ;
     }
     char filemode[11];
     (void)strmode(buf.st_mode,filemode); //another option TA told me
     if ( filemode[0] == 'd' )
        strcat(entry[i],"/");
     else if (filemode[0] == 'l')
        strcat(entry[i],"@");
     else if (filemode[0] == 's')
        strcat(entry[i],"=");
     else if (filemode[0] == 'w')
        strcat(entry[i],"%");
     else if (filemode[0] == 'p')
        strcat(entry[i],"|");
     else if (filemode[3] == 'x'||filemode[6] =='x'|| filemode[9]=='x'||
                                filemode[3] == 's'||filemode[6] == 's')
        strcat(entry[i],"*");
  }
  return 0 ;
}

void
specialchardisplay(char ** entry, int entrycount, int style){
  int i;
  (void)entrysort(entry, entrycount);
  if ( style == 0 ){
     for ( i = 0 ; i < entrycount; ++ i){
        if( *entry[i] != '.'){
	   struct stat buf;
           if (lstat(entry[i],&buf) == -1){
               fprintf(stderr,"can't stat %s:%s\n",entry[i],strerror(errno));
	       freechararray(entry,entrycount);
               exit(EXIT_FAILURE);  
           }
	   char filemode[11];
           (void)strmode(buf.st_mode,filemode); //another option TA told me
           printf("%s",entry[i]);
	   if ( filemode[0] == 'd' )
	      printf("/\n");
           else if (filemode[0] == 'l')
	      printf("@\n");
           else if (filemode[0] == 's')
 	      printf("=\n");
	   else if (filemode[0] == 'w')
	      printf("%%\n");
	   else if (filemode[0] == 'p')
	      printf("|\n");
      	   else if (filemode[3] == 'x'||filemode[6] =='x'|| filemode[9]=='x'||
                                filemode[3] == 's'||filemode[6] == 's')
              printf("*\n");
	   else
 	      printf("\n");
        }
     }
  }
}

//Display the entry in multi columns
void
coldisplay(char ** entry, int entrycount, int style){
  //get the stdin window's col width  
  struct winsize w ;
  if ( ioctl(0,TIOCGWINSZ,&w) != 0 ){
     fprintf(stderr,"can't get col size :%s\n",strerror(errno));
     freechararray(entry,entrycount);
     return;
  }

  int col;
  col = w.ws_col;
  //sort by entry pathname length,and store the length in entrylen
  int entrylen[entrycount];
  if ( style == 0 || style == 415 || style == 43 || style == 47 ||
	style == 416 || style == 418 || style == 419 || style == 436 ||
	style == 4315){
     (void)pathnamelensort(entry,entrycount,entrylen,0);
  }
  //-C = 4, -A =1 ; -C=4, -c=3, -A=1
  else if ( style == 41 || style == 431){
     (void)pathnamelensort(entry,entrycount,entrylen,1);
  }
  else{
     (void)pathnamelensort(entry,entrycount,entrylen,2);
  }
  //if the largest length greater than current windows col num, display
  //all entries in one column
  int i, j;
  if ( entrylen[0] > col){
     //option -Cc, sort the entry by status last change; -C=4, -c=3, -A=1
     // -C=4, -c=3, -a=2
     if ( style == 43 || style == 431 || style == 432 ||
				style == 4315){
	(void)ctimesort(entry,entrycount); 	
     }
     //option -CS: -C=4, -S=16
     else if ( style == 416){
	(void) entrysizesort(entry,entrycount);	
     }
     //option -Ct: -C=4, -t=18
     else if (style == 418){
	(void)modifiedtimesort(entry,entrycount);
     }
     //option -Cu: -C=4, -u=19
     else if ( style == 419){
	(void)accesstimesort(entry,entrycount);
     }
     //415: -C=4,-r=15 ; 41:-C=4,-A=1; 42:-C=4,-a=2;
     else if (style == 415 || style == 0 || style == 41 || style == 42){
        (void)entrysort(entry,entrycount);
     }
     //style == 0 means no other options
     for ( i = 0 ; i < entrycount; ++ i){
        //style == 0 means no other options, 47:-C=4,-f=7; 416:-C=4,-S=16
	if ( (style == 0 || style == 47 || style == 416) && 
						*entry[i] != '.'){
 	    printf("%s\n",entry[i]);
	}
	//option -CA  ;-C=4, -c=3, -A=1
        else if ((style == 41||style == 431) && strcmp(entry[i],".")!=0 &&
				strcmp(entry[i],"..")!=0){
	    printf("%s\n",entry[i]);
	}
	//option -Cc :-C=4, -c=3 ; -Ct: -C=4 -t=18;  -Cu: -C=4 -u=19 
	else if ((style == 43 || style == 418 || style == 419 || 
			style == 436) && *entry[i] != '.'){
            printf("%s\n",entry[i]);
        }
	//option -Ca or -Cca
	else if (style == 42 || style == 432){
	    printf("%s\n",entry[i]);
	}
        //option -Cr, reverse the order to output
        else if ( (style == 415||style == 4315)&& *(entry[entrycount-1-i])!='.'){
	     printf("%s\n",entry[entrycount-1-i]);
	}
     }
     freechararray(entry,entrycount);
     return; 
  }

  int colnum = 0; //estimate the number of entries will display in each row
  while ( col > 0 ){
     //-2 means, the interval of two entries at least 2
     col = col - entrylen[colnum++] - 2;
  }

  if ( col < 0 ) 
     colnum = colnum - 1 ;
   
  int row;//the number of rows need to display all the entries
  int total = 0; // the number of entryies need to display
  
  for ( i = 0 ; i < entrycount; ++ i){
      if ( (style == 0 || style == 47 || style == 415 || style == 416) 
						 && *entry[i] != '.'){
         total = total + 1;
      }
      //option -CA or -CcA
      else if ( (style == 41||style == 431) && strcmp(entry[i],".")!=0 &&
                                strcmp(entry[i],"..")!=0){
         total =  total + 1;
      }
      //option -Cc or Ct
      else if ( (style == 43|| style == 418 || style == 419||style == 436
			||style == 4315)  && *entry[i] != '.'){
         total =  total + 1;
      }
      //option -Ca -Cca
      else if ( style == 42 || style == 432){
	 total =  total + 1;
      }
  }
   
  row = total / colnum;
  if ( (total % colnum) != 0)
     row = row + 1;
  
  //printf("row = %d, colnum = %d \n",row, colnum);
  int maxlen[colnum]; //record longest pathname for each column
  for ( i = 0 ; i < colnum ; ++ i)
      maxlen[i] = 0 ;

  //since the last raw may not be full, I need to check that
  int notfull = row*colnum;
  for ( i = 0 ; i < entrycount ; ++ i){
      if ((style == 0 || style == 47 || style == 415 || style == 416)
						 &&  *entry[i] != '.'){
	 notfull = notfull-1;
      }
      //option -CA
      else if ( (style == 41 || style == 431) && strcmp(entry[i],".")!=0 &&
                                strcmp(entry[i],"..")!=0){
         notfull = notfull-1;
      }
      //option -Cc or -Ct or -Cu
      else if ( (style == 43 || style == 418 || style == 419||style == 436
			||style == 4315) && *entry[i] != '.'){
         notfull = notfull-1;
      }
      //option -Ca -Cca
      else if (style == 42 || style == 432){
	 notfull = notfull-1;
      }
  }

  int full = colnum;
  if ( notfull != 0 ){
     full = colnum - notfull; 
  }
 
  //printf("full = %d\n", full);
  //sort accordingly
  if ( style == 43 || style == 431 || style == 432 || style == 4315){
      (void)ctimesort(entry,entrycount);
  }
  else if(style == 0 || style == 41 || style == 42 || style == 415){
      (void)entrysort(entry,entrycount);
  }
  else if ( style == 416){
      (void) entrysizesort(entry,entrycount);
  }
  else if ( style == 418){
      (void)modifiedtimesort(entry,entrycount);
  }
  else if ( style == 419){
      (void)accesstimesort(entry,entrycount);
  }


  //estimate each colunm's longest entries(I did this all for 
  //right justify the output)
  int max;
  for ( i = 0 ; i < full; ++ i){
     max = 0 ;
     for ( j = 0 ; j < row ; ++ j){
        int temp = findentrylen(entry,entrycount,i*row+j,style);
        if ( temp > max )
	   max =  temp ;
     }
     maxlen[i] = max ;
  }
  for ( i = full ; i < colnum ; ++ i){
     max = 0 ;
     for ( j = 0 ; j < row-1 ; ++ j ){
	int temp = findentrylen(entry,entrycount,
			    (i-full)*(row-1)+full*row + j,style);
        if ( temp > max )
	   max = temp;
     }
     maxlen[i] = max;
  }
  
  //got all info I need, right justify print out entries in multiple colnumn
  int index, count = 0 ;
  //right justify, print out the entry in multiple colnumn
  //printf("total = %d \n", total);
  for ( i = 0 ; i < row; ++ i){
     for ( j = 0 ; j < colnum ; ++ j ){
        if ( j < full )
	   index = j*row + i; 
        else
 	   index = full*row + (j-full)*(row-1) + i ;

        //printf("printing [%d,%d] and index = %d\n",i,j,index);
        (void)displayentrybyloc(entry,entrycount,index,
						maxlen[j],style);
        count = count + 1 ;
        if ( count == total){
           printf("\n");
           freechararray(entry,entrycount);
           return ;
        }
     }
     printf("\n");
  }
}

void
displayentrybyloc(char ** entry, int entrycount, int index,
		int maxlen, int style){
   int i, temp = -1, j ;
   for( i = 0 ; i < entrycount; ++ i ){
      if ( (style == 0 || style == 47 || style == 416 || 
		style == 439) && *entry[i] != '.'){
         temp = temp + 1;
      }
      //option -CA or -CcA , -A=1
      else if ((style == 41 || style == 431) && 
	strcmp(entry[i],".")!=0 && strcmp(entry[i],"..")!=0){
         temp = temp + 1;
      }
      //option -Cc or -Cs or -Ct CcF, or -Cu
      else if ( (style == 43|| style == 417 || style == 418 ||
	   style == 436||style == 419 || style == 4317)
					 && *entry[i] != '.'){
         temp = temp + 1;
      }
      //option -Ca -Cca
      else if ( style == 42 || style == 432){
	 temp = temp + 1;
      }
      //option -Cr
      else if ( (style == 415 || style == 4315)
				 && *entry[entrycount-1-i]!='.'){
	 temp = temp + 1;
      }

      if ( index == temp){
          if ( style == 415 || style == 4315){
	      printf("%s",entry[entrycount-1-i]);
              int blank = maxlen - strlen(entry[entrycount-1-i]);
              for ( j = 0 ; j < blank+2 ; ++j)
                  printf(" ");
              return ;
	  }
         
          printf("%s",entry[i]);
          int blank = maxlen - strlen(entry[i]);
          for ( j = 0 ; j < blank+2 ; ++j)
	     printf(" ");
          return ;
      }
   } 

}

int
findentrylen(char ** entry, int entrycount,int loc, int style){
    int i, index = -1;
    
    for ( i = 0 ; i < entrycount; ++ i){
        if ((style == 0 || style == 47 || style == 416 || 
		style == 4317) &&  *entry[i] != '.'){
            index = index + 1;
        }
	//option -CA or -CcA
	else if ((style == 41 || style == 431) && strcmp(entry[i],".")!=0 &&
                                strcmp(entry[i],"..")!=0){
	    index = index + 1;
	}
	//option -Cc or Cs or Ct
	else if ((style == 43 || style == 417 || style == 418 ||
	     style ==439||style == 436||style == 419) && *entry[i] != '.'){
            index = index + 1;
        }
	//option -Ca -Cca
	else if ( style == 42 || style == 432){
	    index = index + 1;
	}
	else if ( (style == 415 || style == 4315) && *entry[entrycount-1-i]!='.'){
	    index = index + 1;
	}

        if ( index == loc){
            if ( style == 415 || style == 4315){
		return strlen(entry[entrycount-1-i]);
	    }
  	    return strlen(entry[i]);
	}
    }
    
    return -1 ;
}

int
findmaxloc(int * array, int num){
  int i , max_num = 0 ;
  for ( i = 0 ; i < num; ++ i ){
      if ( array[i] > max_num)
	 max_num = array[i];
  }
  return max_num;
}
void
pathnamelensort(char ** entry, int entrycount, int *entrylen, int style){
  int temp = 0;
  //switch Sort
  int i, j;
  for ( i = 0 ; i < entrycount ; ++ i ){
      entrylen[i] = 0 ;
  }
  for ( i = 0 ; i < entrycount ; ++ i ){
     if ( style == 0 && *entry[i] != '.'){
	entrylen[i] = (int)strlen(entry[i]);
     }
     else if ( style == 1 && strcmp(entry[i],".")!= 0 &&
					strcmp(entry[i],"..")!= 0){ 
        entrylen[i] = (int)strlen(entry[i]);
     }
     else if ( style == 2){
	entrylen[i] = (int)strlen(entry[i]);
     }
  }
  for (i = 0 ; i < entrycount ; ++ i)
      for ( j = i+1 ; j < entrycount ; ++j ){
          if ( entrylen[i] < entrylen[j] ){
             temp = entrylen[i];
	     entrylen[i] = entrylen[j];
	     entrylen[j] = temp;
          }
      }
}

void
ctimedisplay(char ** entry, int entrycount, int style){
  (void) ctimesort(entry,entrycount);
  int i;
  if ( style == 0 ){
     for ( i = 0 ; i < entrycount ; ++ i)
        if ( *entry[i] != '.' )
            printf("%s\n",entry[i]);
  }
}

/*sort entries according to status change time
 *
 */
void
ctimesort(char** entry, int entrycount){
  char temp[PATH_MAX+1];
  //switch Sort
  int i, j;
  for (i = 0 ; i < entrycount ; ++ i){
      struct stat buf1;
      if ( lstat(entry[i],&buf1) == -1){
         fprintf(stderr,"can't stat %s:%s\n",entry[i],strerror(errno));
	 freechararray(entry,entrycount);
	 exit(EXIT_FAILURE);
      }
      double cur_max = (double)buf1.st_ctim.tv_sec; 
      for ( j = i+1 ; j < entrycount ; ++j ){
          struct stat buf2;
          if ( lstat(entry[j],&buf2) == -1){
             fprintf(stderr,"can't stat %s:%s\n",entry[j],strerror(errno));
	     freechararray(entry,entrycount);
	     exit(EXIT_FAILURE);
          }
          //double temp = difftime(buf1.st_ctim.tv_sec,buf2.st_ctim.tv_sec);
          double candidate = (double)buf2.st_ctim.tv_sec;
          if ( candidate > cur_max ){
             strcpy(temp,entry[i]);
             strcpy(entry[i],entry[j]);
             strcpy(entry[j], temp);
	     cur_max = candidate;
          }
      } 
  }

}

int
blockcount(int *blocknum,char **entry,int entrycount){
  int i, maxblnum = 0, blocksize = 512 ;

  char *bs;
  char *ptr;
  if ( (bs = getenv("BLOCKSIZE")) !=NULL){
      long bs_temp;
      bs_temp = strtol(bs,&ptr,10);
      if (  (bs_temp > (long)0) && (bs_temp <= (long)INT_MAX) ){
	 blocksize = (int)bs_temp;
      } 
  }

  for ( i = 0 ; i < entrycount ; ++ i){
      struct stat buf;
      if ( lstat(entry[i],&buf) == -1){
         fprintf(stderr,"can't stat %s:%s\n",entry[i],strerror(errno));
      }
      blocknum[i] = (int)buf.st_blocks;
      //change the block num count according to BLOCKSIZE, assume the
      //defaut size showed by stat is 512 Byte
      blocknum[i] = (blocknum[i] * 512) / blocksize;
      if (blocknum[i] > maxblnum)
         maxblnum = blocknum[i];
  }
  return maxblnum;
}

int
sizecount(int * sizec, char ** entry, int entrycount,int * maxmajor,
			int * maxminor, int style){
  int i, sizemax = 0;
  for ( i = 0 ; i < entrycount ; ++ i){
      struct stat buf;
      if ( lstat(entry[i],&buf) == -1){
         fprintf(stderr,"can't stat %s:%s\n",entry[i],strerror(errno));
      }
      sizec[i] = (int)buf.st_size;
      if (sizec[i] > sizemax)
         sizemax = sizec[i];
      //update the maximum length of the major and minor device number
      if (S_ISCHR(buf.st_mode) || S_ISBLK(buf.st_mode)){
	if ( (int)MAJOR(buf.st_dev) > *maxmajor ){
	     *maxmajor = (int)MAJOR(buf.st_dev);
	}
        if ( (int)MINOR(buf.st_dev) > *maxminor){
  	     *maxminor = (int)MINOR(buf.st_dev);
	}
        if ( sizemax < ((*maxmajor)+(*maxminor)+2)){
            sizemax = (*maxmajor)+(*maxminor)+2;
	}
      } 
      
  }
  if (style == 0){
     struct stat buf;
     if ( lstat(".",&buf) == -1){
         fprintf(stderr,"can't stat %s:%s\n",".",strerror(errno));
     }
     sizec[i] = (int)buf.st_size;
  }
  return sizemax; 

}

int
hardlinkcount(int * linkc, char ** entry, int entrycount, int style){
  int i, linkmax = 0 ;
  for ( i = 0 ; i < entrycount ; ++ i){
      struct stat buf;
      if ( lstat(entry[i],&buf) == -1){
         fprintf(stderr,"can't stat %s:%s\n",entry[i],strerror(errno));
      }
      linkc[i] = (int)buf.st_nlink;
      if ( style == 0 ){
	 if ( (linkc[i] > linkmax) && (*entry[i] != '.'))
            linkmax = linkc[i];
      }
  }
  return linkmax;
}

void
lfdisplay(char ** entry,int entrycount, int style){
  int linkc[entrycount];
  int linkmax = 0;
  //the last argument 0 means don't count the file start with "."
  if (style == 0 || style == 1 ){
     linkmax = hardlinkcount(linkc,entry, entrycount,0);
  }

  //get the file size array for the entries and/or the current dir
  //+1 means the dir
  int sizec[entrycount+1];
  int sizemax = 0 ;
  // 0 means count the size of current directory, if there has 
  //spelcial file need to recored the major and minor number
  int maxmajor[1] , maxminor[1];
  maxmajor[0] = -1 ;
  maxminor[0] = -1 ;
  sizemax = sizecount(sizec,entry,entrycount,maxmajor,maxminor, 0);

  //get the file block num for the entries
  int blocknum[entrycount];
  blockcount(blocknum,entry,entrycount);
  int i, dirbl = 0 ;
  //count the block allocated by for the directory by sum up the block 
  //allocated for each entry in this directory, except the ".."
  for ( i = 0 ; i < entrycount ; ++ i ){
       if ( strcmp(entry[i],"..") != 0){
          dirbl += blocknum[i];
       }
  }
  //print out the totol block size in this directory
  printf("total %d\n",dirbl);
  //test : printf("total %d\n",(int)(sizetotal/1024));
  
  //get the maxlen of username and groupname
  int maxusername, maxgroupname;
  if ( style == 0 ){
     maxusername = calculatemaxuserlen(entry,entrycount,0);
     maxgroupname = calculatemaxuserlen(entry,entrycount,1);
  }
  for ( i = 0 ; i < entrycount; ++ i){
      struct stat buf; 
      if ( lstat(entry[i],&buf) == -1){
         fprintf(stderr,"can't stat %s:%s\n",entry[i],strerror(errno));
      }
      if ( (style == 0 || style == 1)  && !(*entry[i] == '.')){
         //display file mode
         char filemode[11];
         (void)strmode(buf.st_mode,filemode); //another option TA told me
 	 printf("%s",filemode);
         
         //display hardlink number
	 int j, maxlen, len;
         maxlen = checklenofnum(linkmax);
         len = checklenofnum(linkc[i]);
         for ( j = 0 ; j < maxlen-len; ++ j)
             printf(" ");
         printf("%d",linkc[i]);
	 
         printf(" ");
  	 //display username and group name
         displaynames(buf,maxusername,maxgroupname,style);
         
         //display number of bytes in file
	 maxlen = checklenofnum(sizemax);
         len = checklenofnum(sizec[i]);
         /*If the file is a character special or block special file,
         //the major and minor device numbers for the file are displayed
         //in the size field. The code is a little messy here, since I 
         want to left-justfy the output format.
         */ 
         int majornum = -1, minornum = -1 ;
         if ( S_ISCHR(buf.st_mode) || S_ISBLK(buf.st_mode) ){
	    majornum = (int)MAJOR(buf.st_dev);
            minornum = (int)MINOR(buf.st_dev);
 	    len = majornum+minornum+2; //+2 means the "," and " "
            for ( j = 0 ; j < maxlen-len; ++ j)
                printf(" ");
	    len = checklenofnum(majornum);
            for ( j = 0 ; j < *maxmajor-len; ++ j)
                printf(" ");
	    printf("%d, ",majornum);
	    len = checklenofnum(minornum);
	    for ( j = 0 ; j < *maxminor-len; ++ j)
                printf(" ");
  	    printf("%d", minornum);
	 } else{
                for ( j = 0 ; j < maxlen-len; ++ j)
                    printf(" ");
                 printf("%d",sizec[i]);
                 printf(" ");
	 } 

         //display the time
  	 (void)displaytime(buf);
         if (S_ISLNK(buf.st_mode)){
	    printf("%s -> ", entry[i]);
            char realpath[PATH_MAX];
            readlink(entry[i],realpath,PATH_MAX);
            printf("%s\n",realpath);
	 }else{
            printf("%s", entry[i]);
 	    printf("\n");
 	 }       
      }
  }
}

void displaytime(struct stat buf){
  char * timezone ;
  if ( (timezone = getenv("TZ")) != NULL){
        setenv("TZ", timezone, 1);
  }
  time_t t = buf.st_mtime;
  struct tm *temp;
  temp = localtime(&t);
  char ftime[10]; //fulname of month should need this length
  strftime(ftime,10,"%b",temp);
  printf("%s ",ftime);
  strftime(ftime,10,"%d",temp);
  printf("%s ",ftime);
  strftime(ftime,10,"%H",temp);
  printf("%s:",ftime);
  strftime(ftime,10,"%M",temp);
  printf("%s ",ftime);
}

int
checklenofnum(int num){
  //assume the hardlink value is no more than 32 bit in decimal
  char str[32];
  sprintf(str, "%d", num);  
  return (int)strlen(str);
}

int
calculatemaxuserlen(char** entry, int entrycount,int style){
  int i ;
  int maxlen = 0 ;
  for ( i = 0 ; i < entrycount; ++ i){
      struct group *grp;
      struct passwd *pwd;
      struct stat buf;
      if ( lstat(entry[i],&buf) == -1){
         fprintf(stderr,"can't stat %s:%s\n",".",strerror(errno));
      }
      errno = 0 ;
      if ( style == 0 ){
         if ((pwd = getpwuid(buf.st_uid)) == NULL ){
             //no error happen and the user is unknow, print the numeric value
             if (errno == 0 && (checklenofnum((int)buf.st_uid) > maxlen))
		maxlen = checklenofnum((int)buf.st_uid);              
             else{
                fprintf(stderr,"can't get username for userID %d:%s\n",
                                        (int)buf.st_uid,strerror(errno));
                exit(EXIT_FAILURE);
             }
         } else{
             if ( strlen(pwd->pw_name) > maxlen)
		 maxlen = strlen(pwd->pw_name);
	     }
      }
      if ( style == 1 ){
          if ((grp = getgrgid(buf.st_gid)) == NULL){
             if (errno == 0 && (checklenofnum((int)buf.st_gid) > maxlen))
		maxlen = checklenofnum((int)buf.st_gid);
             else{
                fprintf(stderr,"can't get groupname for gourpID %d:%s\n",
                                        (int)buf.st_gid,strerror(errno));
                exit(EXIT_FAILURE);
             }
          } else
             if ( strlen(grp->gr_name) > maxlen)
		maxlen = strlen(grp->gr_name);
       }
  }
  return maxlen;
}
                   

void
displaynames(struct stat buf, int maxusername,int maxgroupname, int style){
  struct group *grp;
  struct passwd *pwd;
  errno = 0 ;
  //style = 1 means the -n options is set, print the numeric name 
  if ( style == 1 ){
     printf("%d %d ",buf.st_uid, buf.st_gid);
  }
  //style = 0 means nomal display according to the documentation
  if ( style == 0 ){
     if ((pwd = getpwuid(buf.st_uid)) == NULL ){
         //no error happen and the user is unknow, print the numeric value
         if (errno == 0){
 	    int j;
	    for ( j = 0 ; j < maxusername-checklenofnum((int)buf.st_uid); ++ j)
                printf(" ");
            printf("%d ",(int)buf.st_uid);
	 }
         else{
            fprintf(stderr,"can't get username for userID %d:%s\n",
					(int)buf.st_uid,strerror(errno));
	    exit(EXIT_FAILURE);
         }
     } else{
	 int j;
 	 for ( j = 0 ; j < maxusername-(int)strlen(pwd->pw_name); ++ j)
                printf(" ");
         printf("%s ",pwd->pw_name);
     } 
     if ((grp = getgrgid(buf.st_gid)) == NULL){
         if (errno == 0){
            int j;
	    for ( j = 0 ; j < maxgroupname-checklenofnum((int)buf.st_gid); ++ j)
                printf(" ");
            printf("%d ",(int)buf.st_gid);
	 }
         else{
            fprintf(stderr,"can't get groupname for gourpID %d:%s\n",
                                        (int)buf.st_gid,strerror(errno));
            exit(EXIT_FAILURE);
         }
     } else{
	 int j;
         for ( j = 0 ; j < maxgroupname-(int)strlen(grp->gr_name); ++ j)
                printf(" ");
         printf("%s ", grp->gr_name);
     }
  }
}

void
entrysort(char ** entry, int entrynum){
  char temp[PATH_MAX+1];
  //switch Sort
  int i, j;
  for (i = 0 ; i < entrynum-1 ; ++ i)
      for ( j = i+1 ; j < entrynum ; ++j ){
          if ( strcmp(entry[i],entry[j]) > 0 ){
             strcpy(temp,entry[i]);
             strcpy(entry[i],entry[j]);
             strcpy(entry[j], temp);
          }
      }
}


int
countoptions(char * flags){
   int i, sum = 0 ;
   for ( i = 0 ; i < OPTION_NUM ; ++ i)
      sum += flags[i];

   //deal with some overwrite here
   //when only -C, -h are set, just behave like -C
   if ( sum == 2  && flags[3] == 1 && flags[7] == 1){
	flags[7] = 0;
        sum = sum - 1 ;
   }
   
   //when only -C, -k are set, just behave like -C
   if ( sum == 2  && flags[3] == 1 && flags[9] == 1){
        flags[9] = 0;
        sum = sum - 1 ;
   }

   //when only -C, -l are set, just behave like -l
   //since -l print the result in each line by defaut
   if ( sum == 2  && flags[3] == 1 && flags[10] == 1){
        flags[3] = 0;
        sum = sum - 1 ;
   }
   //when only -C, -n are set, just behave like -n
   if ( sum == 2  && flags[3] == 1 && flags[11] == 1){
        flags[3] = 0;
        sum = sum - 1 ;
   }
   
   //since -C is a default set, so -C and -1 both not set
   //and the user didn't redirect the output to file
   if ( flags[21] == 0 && flags[3] == 0 && isatty(fileno(stdout))){
       flags[3] = 1;
       sum = sum + 1;
   }

   //-n and -l will overwrite -C
   if ( (flags[10] == 1 || flags[11] == 1) && flags[3] == 1){
       flags[3] = 0;
       sum = sum - 1;
   }
   
   //-h is set only if -s or -l is set
   if ( flags[10] == 0 && flags[16] == 0 && flags[7] == 1){
       flags[7] = 0;
       sum = sum - 1;
   }   
 
   //-k is set only for -s
   if ( flags[9] == 1 && flags[16] == 0 ){
      flags[9] = 0;
      sum = sum -1 ;
   }
   
   //-c is set for -t and -l,if none of them is set, then set -c = 0
   if ( flags[17] == 0 && flags[10] == 0 && flags[2] == 1 ){
      flags[2] = 0;
      sum = sum - 1;
   }
   //-u is set for -t and -l,if none of them is set, then set -c = 0
   if ( flags[17] == 0 && flags[10] == 0 && flags[18] == 1 ){
      flags[18] = 0;
      sum = sum - 1;
   }

   //-s will be changed by -h or -k
   if ( flags[16] == 1 && (flags[7] == 1 || flags[9] == 1)){
      flags[16] = 0;
      sum = sum - 1;
   }
   //check if the user is a super user or not, set -A for super
   //user
   uid_t euid=geteuid();
   if ( euid == 0 && flags[0] == 0 && flags[1] == 0){
      flags[0] = 1;
      sum = sum + 1;
   }
   
   //don't have enough time to implement all the possible combination
   //so when -1 is set, This program support -1 + another option + arguments
   if ( flags[21] == 1 ){
      flags[21] = 0;
      sum = sum - 1 ; 
   }
   
   //in order to support my no options part
   if ( sum == 1 && flags[3] == 1 ){
      flags[3] = 0;
      sum = 0 ;
   }

   return sum;
}

/*****************************************
 *Return the file type
 * 0 : regular file 
 * 1 : directory
 * 2 : character special
 * 3 : block special
 * 4 : fifo
 * 5 : symbolic link
 * 6 : socket
 * -1 : no such file or dirctory
 ****************************************** 
 */
int
checkfiletype(char * pathname){
   struct stat buf;
   
   if( (stat(pathname, &buf)) < 0 ){
      fprintf(stderr, "ls(1): can't access %s:%s\n",pathname,strerror(errno));
      return -1;
   }
   
   if ( S_ISREG(buf.st_mode))
      return 0;
   else if (S_ISDIR(buf.st_mode))
      return 1;
   else if (S_ISCHR(buf.st_mode))
      return 2;
   else if (S_ISBLK(buf.st_mode))
      return 3;
   else if (S_ISFIFO(buf.st_mode))
      return 4;
   else if (S_ISLNK(buf.st_mode))
      return 5;
   else if (S_ISSOCK(buf.st_mode))
      return 6;
   else  
      return -1;
}

/***********************************************************
 *Check what kinds of options have been set by the user
 *Return a char array, 1 means the option is set, 0 means
 *the option didn't set
 *the coressponding order is −AacCdFfhiklnqRrSstuwx1
 ***********************************************************
 */
char *
getoptionflags(int argc, char** argv){
   char * flags;
   if ( (flags = malloc(OPTION_NUM)) == NULL){
      fprintf(stderr, "ls(1): system error : %s\n",strerror(errno));
      exit(EX_OSERR);
   }
   //Initialize the flags frist
   int i, ch;
   for ( i = 0 ; i < OPTION_NUM ; ++ i)
      flags[i] = 0 ;

   //The order of the options : −AacCdFfhiklnqRrSstuwx1
   while ((ch = getopt(argc, argv, "AacCdFfhiklnqRrSstuwx1")) != -1){
	switch(ch){
        //needs to deal with the options overwrite here
	case 'A':
              if ( flags[1] == 0)
	         flags[0] = 1 ;
	      break;
        case 'a':
	      if ( flags[0] == 1 ) flags[0] = 0 ;//-a overwrite -A
              flags[1] = 1 ;
              break;
        case 'c':
	      if ( flags[6] == 0)
                  flags[2] = 1 ;
  	      if ( flags[17] == 1 && flags[2] == 1)
	 	  flags[18] = 0;  //-u and -c modifies -t together, so overrides
              break;
        case 'C':
              if ( flags[21] == 1) flags[21]=0;//overwirte
              flags[3] = 1 ;
              break;
        case 'd':
              flags[4] = 1 ;
              break;
        case 'F':
              flags[5] = 1 ;
              break;
        case 'f':
              //-f overwrite all sorting option
	      flags[2] = 0; flags[15]=0; flags[17] = 0; flags[18] = 0 ;
              flags[6] = 1 ;
              break;
        case 'h':
              flags[7] = 1 ;
	      flags[9] = 0;
              break;
        case 'i':
              flags[8] = 1 ;
              break;
        case 'k':
              flags[9] = 1 ;
	      flags[7] = 0;
              break;
        case 'l':
	      if (flags[11] == 0)
                 flags[10] = 1 ;
              break;
        case 'n':
	      if( flags[10] == 1) flags[10] = 0; //-n overwrite -l
              flags[11] = 1 ;
              break;
        case 'q':
              flags[12] = 0 ; //not implemented yet
              break;
        case 'R':
              flags[13] = 1 ;
              break;        
        case 'r':
              flags[14] = 1 ;
              break;
        case 'S':
	      if ( flags[6] == 0)
                 flags[15] = 1 ;
	      flags[17] = 0;
              break;
        case 's':
              flags[16] = 1 ;
              break;
        case 't':
	      if( flags[6] == 0)
                 flags[17] = 1 ;
              flags[15] = 0 ;//overrides -S
              break;
        case 'u':
	      if ( flags[6] == 0)
                 flags[18] = 1 ;
              if ( flags[17] == 1 && flags[18] == 1)
		 flags[2] = 0;
              break;
        case 'w':
              flags[19] = 0 ;//not implemented yet
              break;
        case 'x':
              flags[20] = 0 ;// not implemented yet
              break;
        case '1':
	      if ( flags[3] == 1) flags[3]=0;//overwirte
              flags[21] = 1 ;
              break;
        default:
              fprintf(stderr, "usage: %s: −AacCdFfhiklnqRrSstuwx1 [file ...]\n",
                                                                 argv[0]);
 	      exit(EX_USAGE);
        }
   }
   return flags;
}
