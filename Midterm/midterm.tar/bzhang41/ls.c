#include "myfun.h"
#include "nooptions.h"
#include "oneoption.h"
#include "moreoptions.h"
int
main(int argc, char** argv){
  
  //get the options 
  char * flags ;  
  flags = getoptionflags(argc, argv);
  
  //count options and argument number
  int flagsc, argcc;
  
  //since some flags overwrite to each other, needs
  //to record the order of the input options
  flagsc = countoptions(flags);
  argcc = argc - optind ;


  //deal with no options
  if ( flagsc == 0 )
    //this will call funtions defined in nooptions.c
    (void) lsnoflags(argc, argv, argcc);
    
  //deal with 1 option 
   if ( flagsc == 1){
    //this will call functions defined in oneoption.c
    (void) lsoneflags(argc,argv,flags, argcc);
   }

  //deal with 2 options and -C is set
  if ( flagsc >= 2){
//    printf("test   \n");
    (void) lsmoreflags(argc,argv,flags, argcc,flagsc);
  }

  exit(EX_OK);

}
