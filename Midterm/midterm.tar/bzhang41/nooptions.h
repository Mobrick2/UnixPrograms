#ifndef _NOOPTIONS_H
#define _NOOPTIONS_H
#include <unistd.h>
#include <err.h>
#include <stdio.h>
#include <locale.h>
#include <libgen.h>
#include <sys/param.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <bsd/string.h>
#include <sysexits.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <pwd.h>
#include <grp.h>
#include <linux/kdev_t.h>
#include <time.h>
#include <limits.h>

#ifndef PATH_MAX
#define PATH_MAX 256
#endif

void
lsnoflags(int argc, char** argv, int argcc);





#endif
