#include "moreoptions.h"
#include "oneoption.h"
#include "myfun.h"


void
lsmoreflags(int argc,char **argv, char *flags, int argcc, int flagsc){
    
   char *pathname = ".";
   char actualpath [PATH_MAX+1];
   char *ptr = ".";

   //try to support one argument which is a dir, ortherwise, just return
   if(argcc == 1){
     struct stat buf;
     if ( lstat(argv[optind],&buf) == -1){
         fprintf(stderr,"can't stat %s:%s\n",argv[optind],strerror(errno));
         return;
     }
     if ( S_ISDIR(buf.st_mode) ){
 	pathname = argv[optind];
     }
     
     if( (ptr = realpath(pathname,actualpath))== NULL){
	fprintf(stderr,"can't get path %s:%s\n",pathname,strerror(errno));
        return;
     }
     if( chdir(ptr) == -1 ){
	fprintf(stderr,"can't chdir %s:%s\n",pathname,strerror(errno));
        return;
     }
     argcc = 0;
   }  
   
   //the -l option combination 
   if (argcc == 0 && flagsc == 2 && flags[16] == 1 && flags[10] == 1){
      (void)displaywithmoreoptions(ptr,"ls");
   }

   //only two options -C and -A
   if (argcc == 0 && flagsc == 2 && flags[3] == 1 && flags[0] == 1){
      (void)displaywithmoreoptions(ptr,"CA");
   }
  
   //options -C and -a
   if (argcc == 0 && flagsc == 2 && flags[3] == 1 && flags[1] == 1){
      (void)displaywithmoreoptions(ptr,"Ca");
   }
   
   //options -C and -c
   if (argcc == 0 && flagsc == 2 && flags[3] == 1 && flags[2] == 1){
      (void)displaywithmoreoptions(ptr,"Cc");
   }
  
   //options -C and -d
   if (argcc == 0 && flagsc == 2 && flags[3] == 1 && flags[4] == 1){
      (void)displaywithmoreoptions(ptr,"Cd");
   }

   //options -C and -F
   if (argcc == 0 && flagsc == 2 && flags[3] == 1 && flags[5] == 1){
      (void)displaywithmoreoptions(ptr,"CF");
   }

   //options -C and -f
   if (argcc == 0 && flagsc == 2 && flags[3] == 1 && flags[6] == 1){
      (void)displaywithmoreoptions(ptr,"Cf");
   }

   //options -C and -i
   if (argcc == 0 && flagsc == 2 && flags[3] == 1 && flags[8] == 1){
      (void)displaywithmoreoptions(ptr,"Ci");
   }
  
   //options -C and -R
   if (argcc == 0 && flagsc == 2 && flags[3] == 1 && flags[13] == 1){
      (void)displaywithmoreoptions(ptr,"CR");
   }

    //options -C and -r
   if (argcc == 0 && flagsc == 2 && flags[3] == 1 && flags[14] == 1){
      (void)displaywithmoreoptions(ptr,"Cr");
   }
   //options -C and -S
   if (argcc == 0 && flagsc == 2 && flags[3] == 1 && flags[15] == 1){
      (void)displaywithmoreoptions(ptr,"CS");
   }
   //options -C and -s
   if (argcc == 0 && flagsc == 2 && flags[3] == 1 && flags[16] == 1){
      (void)displaywithmoreoptions(ptr,"Cs");
   }
   //options -C and -t
   if (argcc == 0 && flagsc == 2 && flags[3] == 1 && flags[17] == 1){
      (void)displaywithmoreoptions(ptr,"Ct");
   }
   //options -C and -u
   if (argcc == 0 && flagsc == 2 && flags[3] == 1 && flags[18] == 1){
      (void)displaywithmoreoptions(ptr,"Cu");
   }
   
   //options -c and -l
   if (argcc == 0 && flagsc == 2 && flags[2] == 1 && flags[10] == 1){
      (void)displaywithmoreoptions(ptr,"cl");
   }
   
   //options -ctl behave like -cl
   if (argcc == 0 && flagsc == 3 && flags[2] == 1 && flags[17] == 1 &&
							flags[10] == 1){
      (void)displaywithmoreoptions(ptr,"cl");
   }   

   //options -ctn behave like -cn
   if (argcc == 0 && flagsc == 3 && flags[2] == 1 && flags[17] == 1 &&
                                                        flags[11] == 1){
      (void)displaywithmoreoptions(ptr,"cn");
   }

   //options -ct + h|k|c  behave like -Cc
   if (argcc == 0 && flagsc == 3 && flags[2] == 1 && flags[3] == 1 &&
						flags[17] == 1){
      (void)displaywithmoreoptions(ptr,"Cc");
   }

   //options -cAt = cACt = CcAt
   if (argcc == 0 && flagsc == 4 && flags[2] == 1 && flags[0] == 1 &&
	flags[17] == 1 && flags[3] == 1){
      (void)displaywithmoreoptions(ptr,"CcA");
   }
   
   //options -cat = caCt = Ccat
   if (argcc == 0 && flagsc == 4 && flags[2] == 1 && flags[17] == 1 &&
	      flags[1] == 1 && flags[3] == 1){
      (void)displaywithmoreoptions(ptr,"Cca");
   }
   //options -cdt = cdCt
   if (argcc == 0 && flagsc == 4 && flags[2] == 1 && flags[17] == 1 &&
		flags[4] == 1 && flags[3] == 1){
      (void)displaywithmoreoptions(ptr,"Cd");
   }
   //options -cFt = CcFt
   if (argcc == 0 && flagsc == 4 && flags[2] == 1 && flags[17] == 1 &&
			flags[5] == 1 && flags[3] == 1){
      (void)displaywithmoreoptions(ptr,"CcF");
   }
   //options -cht = Ccht = Cct
   if (argcc == 0 && flagsc == 4 && flags[2] == 1 && flags[17] == 1 &&
			flags[7] == 1 && flags[3] == 1){
      (void)displaywithmoreoptions(ptr,"Cc");
   }
   
   if (argcc == 0 && flagsc == 4 && flags[2] == 1 && flags[17] == 1 &&
			flags[8] == 1 && flags[3] == 1){
      (void)displaywithmoreoptions(ptr,"Cci");
   }

   if (argcc == 0 && flagsc == 4 && flags[2] == 1 && flags[17] == 1 &&
                        flags[13] == 1 && flags[3] == 1){
      (void)displaywithmoreoptions(ptr,"cRC");
   }

   if (argcc == 0 && flagsc == 4 && flags[2] == 1 && flags[17] == 1 &&
                        flags[14] == 1 && flags[3] == 1){
      (void)displaywithmoreoptions(ptr,"crC");
   }

   if (argcc == 0 && flagsc == 4 && flags[2] == 1 && flags[17] == 1 &&
                        flags[16] == 1 && flags[3] == 1){
      (void)displaywithmoreoptions(ptr,"Csc");
   }
   //printf("flagsc=%d, argcc=%d\n",flagsc, argcc);

  

}

void lfsizedisplay(char ** entry, int entrycount, int style){

  int  blocksize = 512;
  char *bs;
  char *ptr;
  if ( (bs = getenv("BLOCKSIZE")) !=NULL){
      long bs_temp;
      bs_temp = strtol(bs,&ptr,10);
      if (  (bs_temp > (long)0) && (bs_temp <= (long)INT_MAX) ){
         blocksize = (int)bs_temp;
      }
  }

  int linkc[entrycount];
  int linkmax = 0;
  //the last argument 0 means don't count the file start with "."
  if (style == 0 || style == 1 ){
     linkmax = hardlinkcount(linkc,entry, entrycount,0);
  }

  //get the file size array for the entries and/or the current dir
  //+1 means the dir
  int sizec[entrycount+1];
  int sizemax = 0 ;
  // 0 means count the size of current directory, if there has 
  //spelcial file need to recored the major and minor number
  int maxmajor[1] , maxminor[1];
  maxmajor[0] = -1 ;
  maxminor[0] = -1 ;
  sizemax = sizecount(sizec,entry,entrycount,maxmajor,maxminor, 0);

  //get the file block num for the entries
  int blocknum[entrycount];
  blockcount(blocknum,entry,entrycount);
  int i, dirbl = 0 ;
  //count the block allocated by for the directory by sum up the block 
  //allocated for each entry in this directory, except the ".."
  for ( i = 0 ; i < entrycount ; ++ i ){
       if ( strcmp(entry[i],"..") != 0){
          dirbl += blocknum[i];
       }
  }
  //print out the totol block size in this directory
  printf("total %d\n",dirbl);
  //test : printf("total %d\n",(int)(sizetotal/1024));

  //get the maxlen of username and groupname
  int maxusername, maxgroupname;
  if ( style == 0 ){
     maxusername = calculatemaxuserlen(entry,entrycount,0);
     maxgroupname = calculatemaxuserlen(entry,entrycount,1);
  }
  int maxsizelen = findmaxsizenumlen(entry,entrycount,0);
  for ( i = 0 ; i < entrycount; ++ i){
      struct stat buf;
      if ( lstat(entry[i],&buf) == -1){
         fprintf(stderr,"can't stat %s:%s\n",entry[i],strerror(errno));
      }
      if ( (style == 0 || style == 1)  && *entry[i]!='.'){
         //display block size
         //assume the max len of blocksize is 10
         int temp =  (int)buf.st_blocks*512/blocksize ;
         int j;
         for ( j = 0 ; j < maxsizelen-checklenofnum(temp); ++ j)
	     printf(" ");
         printf("%d ",temp);
         //display file mode
         char filemode[11];
         (void)strmode(buf.st_mode,filemode); //another option TA told me
         printf("%s",filemode);

         //display hardlink number
         int  maxlen, len;
         maxlen = checklenofnum(linkmax);
         len = checklenofnum(linkc[i]);
         for ( j = 0 ; j < maxlen-len; ++ j)
             printf(" ");
         printf("%d",linkc[i]);

         printf(" ");
         //display username and group name
         displaynames(buf,maxusername,maxgroupname,style);

         //display number of bytes in file
         maxlen = checklenofnum(sizemax);
         len = checklenofnum(sizec[i]);
         /*If the file is a character special or block special file,
         //the major and minor device numbers for the file are displayed
         //in the size field. The code is a little messy here, since I 
         want to left-justfy the output format.
         */
         int majornum = -1, minornum = -1 ;
         if ( S_ISCHR(buf.st_mode) || S_ISBLK(buf.st_mode) ){
            majornum = (int)MAJOR(buf.st_dev);
            minornum = (int)MINOR(buf.st_dev);
            len = majornum+minornum+2; //+2 means the "," and " "
            for ( j = 0 ; j < maxlen-len; ++ j)
                printf(" ");
            len = checklenofnum(majornum);
            for ( j = 0 ; j < *maxmajor-len; ++ j)
                printf(" ");
            printf("%d, ",majornum);
            len = checklenofnum(minornum);
            for ( j = 0 ; j < *maxminor-len; ++ j)
                printf(" ");
            printf("%d", minornum);
         } else{
              for ( j = 0 ; j < maxlen-len; ++ j)
                 printf(" ");
                 printf("%d",sizec[i]);
                 printf(" ");
         }
         //display the time
         (void)displaytime(buf);
         if (S_ISLNK(buf.st_mode)){
            printf("%s -> ", entry[i]);
            char realpath[PATH_MAX];
            readlink(entry[i],realpath,PATH_MAX);
            printf("%s\n",realpath);
         }else{
            printf("%s", entry[i]);
            printf("\n");
         }
      }
  }
}

void displaywithmoreoptions(char * pathname, char * options){

   int entrycount = 0 ;
   char ** entry;
   entry = getentryinpath(pathname,&entrycount);

   if( entry != NULL ){

     if ( strcmp(options,"ls") == 0){
 
        (void)lfsizedisplay(entry,entrycount,0);
     }

     if ( strcmp(options,"CA") == 0){
       (void) coldisplay(entry,entrycount,41);
     }
     
     if ( strcmp(options,"Ca") == 0){
        (void)coldisplay(entry,entrycount,42);
     }
     //option -c -t -u is about time
     if ( strcmp(options,"Cc") == 0){
        (void)coldisplay(entry,entrycount,43);
     }

     if ( strcmp(options,"Ct") == 0){
        (void)coldisplay(entry,entrycount,418);
     }

     if ( strcmp(options,"Cu") == 0){
        (void)coldisplay(entry,entrycount,419);
     }
   
     if ( strcmp(options,"CS") == 0){
        (void)coldisplay(entry,entrycount,416);
     }

     if ( strcmp(options,"Cd") == 0){
        //if no arguments input, options Cd behaves like d
        printf("%s\n",pathname);
     }

     if ( strcmp(options,"CF") == 0){
	//first append the special char to each entry
  	if ( appendspecialchartoentry(entry,entrycount) == 0 ){
           (void)coldisplay(entry,entrycount,0);
	}
     }

     if ( strcmp(options,"Cf") == 0){
        (void)coldisplay(entry,entrycount,47);
     }

     if ( strcmp(options,"Ci") == 0){
        (void)coldisplaywithserialnumber(entry,entrycount,0);
     }

     if ( strcmp(options,"Cs") == 0){
        (void)coldisplaywithserialnumber(entry,entrycount,417);
     }

     if ( strcmp(options,"Csc") == 0){
        (void)coldisplaywithserialnumber(entry,entrycount,4317);
     }

     if ( strcmp(options,"CR") == 0){
        char * p = ".";
        char *pp[] = {p, NULL};
	freechararray(entry,entrycount);
        (void)recursivecoldisplayinpath(pp,".","CR",0);
     }

     if ( strcmp(options,"Cr") == 0){
	//-C is 4 and -r is 15
        (void)coldisplay(entry,entrycount,415);
     }

     if ( strcmp(options,"crC") == 0){
        //-C is 4 and -r is 15
        (void)coldisplay(entry,entrycount,4315);
     }

     if ( strcmp(options,"cl") == 0){
        (void)ctimesort(entry,entrycount);
	(void) lfdisplay(entry,entrycount,0);
        return;
     }

     if ( strcmp(options,"cn") == 0){
        (void)ctimesort(entry,entrycount);
        (void) lfdisplay(entry,entrycount,1);
        return;
     }


     if ( strcmp(options,"CcA") == 0){
        //-C = 4, -c=3, -A=1
	(void)coldisplay(entry,entrycount,431);
     }
     if ( strcmp(options,"Cca") == 0){
        //-C = 4, -c=3, -a=2
        (void)coldisplay(entry,entrycount,432);
     }

     if ( strcmp(options,"Cci") == 0){
        (void)coldisplaywithserialnumber(entry,entrycount,439);
     }
     
     if ( strcmp(options,"CcF") == 0){
        //first append the special char to each entry
        (void)ctimesort(entry,entrycount);
        if ( appendspecialchartoentry(entry,entrycount) == 0 ){
           (void)coldisplay(entry,entrycount,436);
        }
     }

     if ( strcmp(options,"cRC") == 0){
        char * p = ".";
        char *pp[] = {p, NULL};
        freechararray(entry,entrycount);
  	//-C=4,-c=3, -R=14
        (void)recursivecoldisplayinpath(pp,".","cRC",43);
     }

   }
}

int
comparename2(const FTSENT ** one, const FTSENT** two){
  return (strcmp((*one)->fts_name,(*two)->fts_name));
}

void
ctimesortwithpathname(char* pathname, char** entry, int entrycount){
  char temp[PATH_MAX+1];
  //switch Sort
  int i, j;
  for (i = 0 ; i < entrycount ; ++ i){
      int  templen = strlen(pathname) + strlen(entry[i]);
      char tempentry[templen+2];
      strcpy(tempentry,pathname);
      strcat(tempentry,"/");
      strcat(tempentry,entry[i]);
      struct stat buf1;
      if ( lstat(tempentry,&buf1) == -1){
         fprintf(stderr,"can't stat %s:%s\n",entry[i],strerror(errno));
         return;
      }
      double cur_max = (double)buf1.st_ctim.tv_sec;
      for ( j = i+1 ; j < entrycount ; ++j ){
	  int templen = strlen(pathname) + strlen(entry[j]);
          char tempentry2[templen+2];
          strcpy(tempentry2,pathname);
          strcat(tempentry2,"/");
          strcat(tempentry2,entry[j]);
          struct stat buf2;
          if ( lstat(tempentry2,&buf2) == -1){
             fprintf(stderr,"can't stat %s:%s\n",entry[j],strerror(errno));
             return;
          }
          //double temp = difftime(buf1.st_ctim.tv_sec,buf2.st_ctim.tv_sec);
          double candidate = (double)buf2.st_ctim.tv_sec;
          if ( candidate > cur_max ){
             strcpy(temp,entry[i]);
             strcpy(entry[i],entry[j]);
             strcpy(entry[j], temp);
             cur_max = candidate;
          }
      }
  }

}


void recursivecoldisplayinpath(char * const *path, char * pathname,
                                char * option, int style){
   //check if this dir has permission to visit
   DIR *dp ;
   if ( (dp = opendir(pathname)) == NULL ){
        fprintf(stderr, "ls(1): can't access %s : %s\n", pathname,
                                                        strerror(errno));
        (void)closedir(dp);
        return;
   }
   printf("%s:\n",pathname);

   int entrycount = 0 ;
   char ** entry;
   entry = getentryinpath(pathname,&entrycount);

   if( entry == NULL ){
       return ;
   }
   else{
       //first print out the entries
       if ( style == 43 ){
	    (void)ctimesortwithpathname(pathname,entry,entrycount);
  	    (void)coldisplay(entry,entrycount,436);
       }
       else{
            (void)coldisplay(entry,entrycount,style);
       }
       //recursive
       //I tried fts(3)
       FTS* rootpath = NULL;
       FTSENT* child = NULL;

       if ( style == 0 || style == 43){
          rootpath = fts_open(path,FTS_NOCHDIR|FTS_PHYSICAL,&comparename2);
       }
       if ( rootpath == NULL ){
          fprintf(stderr, "can't fts %s : %s\n", pathname,strerror(errno));
          return;
       }
       while ( (child = fts_read(rootpath)) != NULL){
           if ( (style == 0 || style == 43) && (child->fts_level == 1) &&
	 (*(child->fts_name))!='.'&& (child->fts_info == FTS_D) ){
               printf("\n");
               char * p = child->fts_path;
               char *pp[] = {p, NULL};
               (void)recursivecoldisplayinpath(pp,child->fts_path,option,style);
           }
       }

       if ( errno != 0){
           fprintf(stderr, "can't fts_read %s : %s\n",pathname,strerror(errno));
       }
       fts_close(rootpath);
       return;
   }


}

int
findseriallen(char ** entry, int entrycount,int loc, int style){
    int i, index = -1;
    int  blocksize = 512;
    char *bs;
    char *ptr;
    if ( (bs = getenv("BLOCKSIZE")) !=NULL){
       long bs_temp;
       bs_temp = strtol(bs,&ptr,10);
       if (  (bs_temp > (long)0) && (bs_temp <= (long)INT_MAX) ){
         blocksize = (int)bs_temp;
       }
    }

    for ( i = 0 ; i < entrycount; ++ i){
        if ((style == 0 || style == 47 || style == 417) &&
						 *entry[i] != '.'){
            index = index + 1;
        }
        //option -CA
        else if (style == 41 && strcmp(entry[i],".")!=0 &&
                                strcmp(entry[i],"..")!=0){
            index = index + 1;
        }
        //option -Cci
        else if ((style == 439||style ==4317) && *entry[i] != '.'){
            index = index + 1;
        }
        //option -Ca
        else if ( style == 42){
            index = index + 1;
        }

        if ( index == loc){
	    struct stat buf;
            if ( lstat(entry[i],&buf) == -1){
              fprintf(stderr,"can't stat %s:%s\n",entry[i],strerror(errno));
              freechararray(entry,entrycount);
               return -1;
            }
	    if ( style == 417 || style == 4317){
	       return checklenofnum((int)buf.st_blocks*512/blocksize);
	    }            
            return checklenofnum((int)buf.st_ino);
        }
    }

    return -1 ;
}


void
displayserialbyloc(char ** entry, int entrycount, int index,
                int maxlen, int style){
   int i, temp = -1, j ;
   int  blocksize = 512;
   char *bs;
   char *ptr;
   if ( (bs = getenv("BLOCKSIZE")) !=NULL){
       long bs_temp;
       bs_temp = strtol(bs,&ptr,10);
       if (  (bs_temp > (long)0) && (bs_temp <= (long)INT_MAX) ){
         blocksize = (int)bs_temp;
       }
   }

   for( i = 0 ; i < entrycount; ++ i ){
      if ( (style == 0 || style == 47) && *entry[i] != '.'){
         temp = temp + 1;
      }
      //option -CA
      else if ( style == 41 && strcmp(entry[i],".")!=0 &&
                                strcmp(entry[i],"..")!=0){
         temp = temp + 1;
      }
      //option -Cci or -Cs
      else if ( (style == 439 || style == 417 || style == 4317) &&
					 *entry[i] != '.'){
         temp = temp + 1;
      }
      //option -Ca
      else if ( style == 42){
         temp = temp + 1;
      }

      if ( index == temp){
          struct stat buf;
          if ( lstat(entry[i],&buf) == -1){
              fprintf(stderr,"can't stat %s:%s\n",entry[i],strerror(errno));
              return;
          }
	  if (style == 417 || style == 4317){
	     int temp = checklenofnum((int)buf.st_blocks*512/blocksize);
	     int blank = maxlen - temp;
             for ( j = 0 ; j < blank ; ++j)
                printf(" ");
             printf("%d ",(int)buf.st_blocks*512/blocksize);
	     return;
	  }
          int temp = checklenofnum((int)buf.st_ino);
          int blank = maxlen - temp;
          for ( j = 0 ; j < blank ; ++j)
             printf(" ");
          printf("%d ",(int)buf.st_ino);
          return ;
      }
   }

}


int
findmaxsizenumlen(char **entry,int entrycount,int style){
  int i, blocksize = 512;
  char *bs;
  char *ptr;
  if ( (bs = getenv("BLOCKSIZE")) !=NULL){
      long bs_temp;
      bs_temp = strtol(bs,&ptr,10);
      if (  (bs_temp > (long)0) && (bs_temp <= (long)INT_MAX) ){
         blocksize = (int)bs_temp;
      }
  }
  int  max = 0;
  for ( i = 0 ; i < entrycount; ++ i ){
      if (style == 0 && *entry[i] != '.'){
         struct stat buf;
         if ( lstat(entry[i],&buf) == -1){
             fprintf(stderr,"can't stat %s:%s\n",entry[i],strerror(errno));
             freechararray(entry,entrycount);
             return -1;
         }
         int temp = (int)buf.st_blocks*512/blocksize;
         if (temp > max){
             max = temp ;
         }
      }
      else if( style == 1 && (strcmp(entry[i],".") != 0) &&
                                         (strcmp(entry[i],"..") != 0)){
         struct stat buf;
         if ( lstat(entry[i],&buf) == -1){
            fprintf(stderr,"can't stat %s:%s\n",entry[i],strerror(errno));
            freechararray(entry,entrycount);
            return -1;
         }
         int temp = (int)buf.st_blocks*512/blocksize;
         if (temp > max){
            max = temp ;
         }
      }
      else{
	 struct stat buf;
         if ( lstat(entry[i],&buf) == -1){
            fprintf(stderr,"can't stat %s:%s\n",entry[i],strerror(errno));
            freechararray(entry,entrycount);
            return -1;
         }
         int temp = (int)buf.st_blocks*512/blocksize;
         if (temp > max){
            max = temp ;
         }
      }	
  }

  max = checklenofnum(max);
  return max; 

}


int
findmaxserialnumlen(char **entry,int entrycount,int style){
   int i, max = 0 ;
   for ( i = 0 ; i < entrycount; ++ i){
     if( style == 0 && *entry[i] != '.'){
       struct stat buf;
       if ( lstat(entry[i],&buf) == -1){
          fprintf(stderr,"can't stat %s:%s\n",entry[i],strerror(errno));
          freechararray(entry,entrycount);
          return -1;
       }
      
       if ( (int)buf.st_ino > max){
	  max = (int)buf.st_ino;
       }
     }
    else if( style == 1 && (strcmp(entry[i],".") != 0) &&
					 (strcmp(entry[i],"..") != 0)){
       struct stat buf;
       if ( lstat(entry[i],&buf) == -1){
          fprintf(stderr,"can't stat %s:%s\n",entry[i],strerror(errno));
          freechararray(entry,entrycount);
          return -1;
       }

       if ( (int)buf.st_ino > max){
          max = (int)buf.st_ino;
       }
     }
    else{
       struct stat buf;
       if ( lstat(entry[i],&buf) == -1){
          fprintf(stderr,"can't stat %s:%s\n",entry[i],strerror(errno));
          freechararray(entry,entrycount);
          return -1;
       }

       if ( (int)buf.st_ino > max){
          max = (int)buf.st_ino;
       }
    }
   }

   max = checklenofnum(max);
   return max;
}

void
coldisplaywithserialnumber(char ** entry, int entrycount, int style){
   //get the stdin window's col width  
  struct winsize w ;
  if ( ioctl(0,TIOCGWINSZ,&w) != 0 ){
     fprintf(stderr,"can't get col size :%s\n",strerror(errno));
     freechararray(entry,entrycount);
     exit(EXIT_FAILURE);
  }

  int col;
  col = w.ws_col;

  //get maximal serial number length
  int serialtype = 0 ;
  if ( style == 41)
	serialtype = 1;
  if ( style == 42)
	serialtype = 2;

  //sort by entry pathname length
  int entrylen[entrycount];
  (void)pathnamelensort(entry,entrycount,entrylen,serialtype);

  int maxserialnumlen = 0;
  //compare serial num option -i
  if ( style == 0 || style == 439 ){
      maxserialnumlen = findmaxserialnumlen(entry,entrycount,serialtype);
  }
  //size number is compared actually, option -s
  else{
     maxserialnumlen = findmaxsizenumlen(entry,entrycount,serialtype);
  }

  if ( maxserialnumlen < 0 ){
     return ;
  }


  //if the largest length greater than current windows col num, display
  //all entries in one column
  int i, j;
  int  blocksize = 512;
  char *bs;
  char *ptr;
  if ( (bs = getenv("BLOCKSIZE")) !=NULL){
      long bs_temp;
      bs_temp = strtol(bs,&ptr,10);
      if (  (bs_temp > (long)0) && (bs_temp <= (long)INT_MAX) ){
         blocksize = (int)bs_temp;
      }
  }

  if ( entrylen[0] > col){
     //option -Cc, sort the entry by status last change
     if ( style == 439 || style == 4317){
        (void)ctimesort(entry,entrycount);
     }
     else if ( style == 0 || style == 41 || style == 42 || style == 417){
        (void)entrysort(entry,entrycount);
     }
     for ( i = 0 ; i < entrycount; ++ i){
	struct stat buf;
        if ( lstat(entry[i],&buf) == -1){
          fprintf(stderr,"can't stat %s:%s\n",entry[i],strerror(errno));
          freechararray(entry,entrycount);
          return;
        }
	
        //style == 0 means no other options, 47 -f no sorting
        if ( (style == 0 || style == 47 || style == 439) && 
						*entry[i] != '.'){
	    int templen = checklenofnum((int)buf.st_ino);
  	    for ( j = 0 ; j < (maxserialnumlen-templen); ++j){
		printf(" ");
	    }    
            printf("%d %s\n",(int)buf.st_ino,entry[i]);
        }
	//option -Cs or -Ccs
        else if ((style == 417 ||style == 4317) && *entry[i] != '.'){
            int templen = checklenofnum((int)buf.st_blocks*512/blocksize);
            for ( j = 0 ; j < (maxserialnumlen-templen); ++j){
                printf(" ");
            }
            printf("%d %s\n",(int)buf.st_blocks*512/blocksize,entry[i]);
        }

        //option -CA
        else if (style == 41 && strcmp(entry[i],".")!=0 &&
                                strcmp(entry[i],"..")!=0){
	    int templen = checklenofnum((int)buf.st_ino);
            for ( j = 0 ; j < (maxserialnumlen-templen); ++j){
                printf(" ");
            }
            printf("%d %s\n",(int)buf.st_ino,entry[i]);
        }
        //option -Cc
        else if (style == 43 && *entry[i] != '.'){
	    int templen = checklenofnum((int)buf.st_ino);
            for ( j = 0 ; j < (maxserialnumlen-templen); ++j){
                printf(" ");
            }
            printf("%d %s\n",(int)buf.st_ino,entry[i]);
        }
        //option -Ca
        else if (style == 42){
	    int templen = checklenofnum((int)buf.st_ino);
            for ( j = 0 ; j < (maxserialnumlen-templen); ++j){
                printf(" ");
            }
            printf("%d %s\n",(int)buf.st_ino,entry[i]);
        }
     }
     freechararray(entry,entrycount);
     return;
  }

  int colnum = 0; //estimate the number of entries will display in each row
  while ( col > 0 ){
     //-2 means, the interval of two entries at least 2, the interval betwwen
     //entry and serial number at least 1
     col = col - entrylen[colnum++] - 2 - maxserialnumlen - 1;
  }

  if ( col < 0 )
     colnum = colnum - 1 ;

  int row;//the number of rows need to display all the entries and serial #
  int total = 0; // the number of entryies need to display

  for ( i = 0 ; i < entrycount; ++ i){
      if ( (style == 0 || style == 47 || style == 439) && *entry[i] != '.'){
         total = total + 1;
      }
      //option -CA
      else if ( style == 41 && strcmp(entry[i],".")!=0 &&
                                strcmp(entry[i],"..")!=0){
         total =  total + 1;
      }
      //option -Cc or -Cs
      else if ( (style == 43 || style == 417 || style ==4317)
							 && *entry[i] != '.'){
         total =  total + 1;
      }
      //option -Ca
      else if ( style == 42){
         total =  total + 1;
      }
  }

  row = total / colnum;
  if ( (total % colnum) != 0)
     row = row + 1;

  //printf("row = %d, colnum = %d \n",row, colnum);
  int maxlen[colnum]; //record longest pathname for each column
  int maxseriallen[colnum];//record longest serial length for each column
  for ( i = 0 ; i < colnum ; ++ i){
      maxlen[i] = 0 ;
      maxseriallen[i] = 0 ;
  }

  //since the last raw may not be full, I need to check that
  int notfull = row*colnum;
  for ( i = 0 ; i < entrycount ; ++ i){
      if ((style == 0 || style == 47 || style == 417) && 
						 *entry[i] != '.'){
         notfull = notfull-1;
      }
      //option -CA
      else if ( style == 41 && strcmp(entry[i],".")!=0 &&
                                strcmp(entry[i],"..")!=0){
         notfull = notfull-1;
      }
      //option -Cci
      else if ( (style == 439 || style == 4317) && *entry[i] != '.'){
         notfull = notfull-1;
      }
      //option -Ca
      else if (style == 42){
         notfull = notfull-1;
      }
  }

  int full = colnum;
  if ( notfull != 0 ){
     full = colnum - notfull;
  }

  //printf("full = %d\n", full);
  //sort accordingly
  if ( style == 439|| style == 4317){
      (void)ctimesort(entry,entrycount);
  }
  else if(style == 0 || style == 41 || style == 42 || style == 417){
      (void)entrysort(entry,entrycount);
  }


  //estimate each colunm's longest entries(I did this all for 
  //right justify the output)
  int max;
  for ( i = 0 ; i < full; ++ i){
     max = 0 ;
     for ( j = 0 ; j < row ; ++ j){
        int temp = findentrylen(entry,entrycount,i*row+j,style);
        if ( temp > max )
           max =  temp ;
     }
     maxlen[i] = max ;
  }
  for ( i = full ; i < colnum ; ++ i){
     max = 0 ;
     for ( j = 0 ; j < row-1 ; ++ j ){
        int temp = findentrylen(entry,entrycount,
                            (i-full)*(row-1)+full*row + j,style);
        if ( temp > max )
           max = temp;
     }
     maxlen[i] = max;
  }

  //estimate each colunm's longest serial num length(I did this all for 
  //right justify the output
  max = 0;
  for ( i = 0 ; i < full; ++ i){
     max = 0 ;
     for ( j = 0 ; j < row ; ++ j){
        int temp = findseriallen(entry,entrycount,i*row+j,style);
        if ( temp > max )
           max =  temp ;
     }
     maxseriallen[i] = max ;
  }
  for ( i = full ; i < colnum ; ++ i){
     max = 0 ;
     for ( j = 0 ; j < row-1 ; ++ j ){
        int temp = findseriallen(entry,entrycount,
                            (i-full)*(row-1)+full*row + j,style);
        if ( temp > max )
           max = temp;
     }
     maxseriallen[i] = max;
  }


  //got all info I need, right justify print out entries in multiple colnumn
  int index, count = 0 ;
  //right justify, print out the entry in multiple colnumn
  //printf("total = %d \n", total);
  for ( i = 0 ; i < row; ++ i){
     for ( j = 0 ; j < colnum ; ++ j ){
        if ( j < full )
           index = j*row + i;
        else
           index = full*row + (j-full)*(row-1) + i ;

        //printf("printing [%d,%d] and index = %d\n",i,j,index);
        (void)displayserialbyloc(entry,entrycount,index,maxseriallen[j],
							style);
        (void)displayentrybyloc(entry,entrycount,index,
                                                maxlen[j],style);
        count = count + 1 ;
        if ( count == total){
           printf("\n");
           freechararray(entry,entrycount);
           exit(EX_OK);
        }
     }
     printf("\n");
  }
}

