#include "myfun.h"
#include "oneoption.h"
#include "nooptions.h"
void
lsoneflags(int argc,char **argv, char *flags, int argcc){
  //The order of the options : −AacCdFfhiklnqRrSstuwx1  
  char *pathname = ".";
  char actualpath [PATH_MAX+1];
  char *ptr = ".";
  
  //try to support one argument which is a dir, ortherwise, just return
   if(argcc == 1){
     struct stat buf;
     if ( lstat(argv[optind],&buf) == -1){
         fprintf(stderr,"can't stat %s:%s\n",argv[optind],strerror(errno));
         return;
     }
     if ( S_ISDIR(buf.st_mode) ){
        pathname = argv[optind];
     }

     if( (ptr = realpath(pathname,actualpath))== NULL){
        fprintf(stderr,"can't get path %s:%s\n",pathname,strerror(errno));
        return;
     }
     if( chdir(ptr) == -1 ){
        fprintf(stderr,"can't chdir %s:%s\n",pathname,strerror(errno));
        return;
     }
     argcc = 0;
   }


  if ( argcc == 0 && flags[0] == 1 ){
     displayentryinpath(ptr,"A");
     exit(EX_OK);
  }   
  
  if ( argcc == 0 && flags[1] == 1 ){
     displayentryinpath(ptr,"a");
     exit(EX_OK);   
  }
  
  if ( argcc == 0 && flags[2] == 1 ){
     displayentryinpath(ptr,"c");
     exit(EX_OK);
  }  

  if ( argcc == 0 && flags[3] == 1 ){
     displayentryinpath(ptr,"C");
     exit(EX_OK);
  }
  
  if ( argcc == 0 && flags[4] == 1 ){
     //if no argument, just display a "."
     printf(".\n");
     exit(EX_OK);
  }
  
  if ( argcc == 0 && flags[5] == 1 ){
     displayentryinpath(ptr,"F");
     exit(EX_OK);
  }
  
  if ( argcc == 0 && flags[6] == 1 ){
     displayentryinpath(ptr,"f");
     exit(EX_OK);
  }
  
  if ( argcc >= 0 && flags[7] == 1 ){
     //since -h modifies other flags, if no other flags
     //it's like no argument and no flags
     (void)lsnoflags(argc,argv,argcc);     
     exit(EX_OK);
  }
  
  if ( argcc == 0 && flags[8] == 1 ){
     displayentryinpath(ptr,"i");
     exit(EX_OK);
  }
  
  if ( argcc >= 0 && flags[9] == 1 ){
     //-k is same as -h
     (void)lsnoflags(argc,argv,argcc);
     exit(EX_OK);
  }

  if ( argcc == 0 && flags[10] == 1 ){
     displayentryinpath(ptr,"l");
     exit(EX_OK);
  }

  if ( argcc == 0 && flags[11] == 1 ){
     displayentryinpath(ptr,"n");
     exit(EX_OK);
  }


  if ( argcc == 0 && flags[13] == 1 ){
     //option -R
     char * p = ptr;
     char *pp[] = {p, NULL};

     recursivedisplayentryinpath(pp,ptr,"R",0);
     exit(EX_OK);
  }
  
  if ( argcc == 0 && flags[14] == 1 ){
     displayentryinpath(ptr,"r");
     exit(EX_OK);
  }
  
  if ( argcc == 0 && flags[15] == 1 ){
     displayentryinpath(ptr,"S");
     exit(EX_OK);
  }
 
  if ( argcc == 0 && flags[16] == 1 ){
     displayentryinpath(ptr,"s");
     exit(EX_OK);
  }

  if ( argcc == 0 && flags[17] == 1 ){
     displayentryinpath(ptr,"t");
     exit(EX_OK);
  }
  
 if ( argcc == 0 && flags[18] == 1 ){
     displayentryinpath(ptr,"u");
     exit(EX_OK);
  }

 if ( argcc >= 0 && flags[21] == 1 ){
     (void)lsnoflags(argc,argv,argcc);
     exit(EX_OK);
  }
 
   
  //has > 0 arguments input
  //first check the largest length of the arguments
  int temp = optind, maxlen = 0;
  while(optind < argc){
     if ( strlen(argv[optind]) > maxlen){
  	maxlen = strlen(argv[optind]);
     }
     optind ++ ;
  }
  
  optind = temp;

  if (argcc > 0 && flags[4] == 1 ){
     char ** entry;
     int entrycount = 0;
     if (( entry = malloc(argcc*sizeof(char*))) == NULL ){
        fprintf(stderr, "ls(1): can't malloc: %s\n",strerror(errno));
        exit(EXIT_FAILURE);
     } 
     struct stat buf;
     while (optind < argc){
         if (lstat(argv[optind],&buf) == -1){
             fprintf(stderr,"can't stat %s:%s\n",argv[optind],strerror(errno));
             optind ++ ;
             continue;
          }
          
          if ((entry[entrycount] = malloc(maxlen+2)) == NULL){
             fprintf(stderr, "ls(1): can't malloc: %s\n",strerror(errno));
             exit(EXIT_FAILURE);
          }
          strcpy(entry[entrycount++],argv[optind]);
          optind++;
     }
     (void)entrydisplay(entry,entrycount,2);
     //(void)freechararray(entry,entrycount);
     exit(EX_OK);
  }  
  

}

int getoption(char * flags){
  int i;
  for ( i = 0 ; i < 22 ; ++ i){
      if(flags[i] == 1){
         return i+1;
      }
  }
  return -1 ;
}

void
recursivedisplayentryinpath(char * const *path, char * pathname,
				char * option, int style){
   //I tried fts(3)
   FTS* rootpath = NULL;
   FTSENT* child = NULL;
   
   if ( style == 0){
     rootpath = fts_open(path,FTS_NOCHDIR|FTS_PHYSICAL,&comparename);
   }
   if ( rootpath == NULL ){
      fprintf(stderr, "can't fts %s : %s\n", pathname,strerror(errno));
      return;
   }

   //check if this dir has permission to visit
   DIR *dp ;
   if ( (dp = opendir(pathname)) == NULL ){
        fprintf(stderr, "ls(1): can't access %s : %s\n", pathname,
                                                        strerror(errno));
        (void)closedir(dp);
	return;
   }
   
   printf("%s:\n",pathname); 
   while ( (child = fts_read(rootpath)) != NULL){
        //output all the entries dirtory + notdirectory, since dir will be visited
	//twice, here is how to print out only once
	if ( (child->fts_level == 1) && style == 0 && (*(child->fts_name))!='.'&&
	     (child->fts_info == FTS_D || !S_ISDIR(child->fts_statp->st_mode)) ){
            printf("%s\n",child->fts_name);
  	}
   }
   //child = fts_read mail failed
   if ( errno != 0){
      fprintf(stderr, "can't fts_read %s : %s\n",pathname,strerror(errno));
      fts_close(rootpath);
      return;
   }

   if ( style == 0){
     rootpath = fts_open(path,FTS_NOCHDIR|FTS_PHYSICAL,&comparename);
   }
   if ( rootpath == NULL ){
      fprintf(stderr, "can't fts %s : %s\n", pathname,strerror(errno));
      return;
   }

   
   while ( (child = fts_read(rootpath)) != NULL){
        if ( (child->fts_level == 1) && style == 0 && (*(child->fts_name))!='.'&&
             			(child->fts_info == FTS_D) ){
	    printf("\n");
	    char * p = child->fts_path;
            char *pp[] = {p, NULL};
            (void)recursivedisplayentryinpath(pp,child->fts_path,option,style);
        }
   }
   
   if ( errno != 0){
      fprintf(stderr, "can't fts_read %s : %s\n",pathname,strerror(errno));
   }
   fts_close(rootpath);
   return;
}

int
comparename(const FTSENT ** one, const FTSENT** two){
  return (strcmp((*one)->fts_name,(*two)->fts_name));
}

void
displayentryinpath( char * pathname, char *option){

  int entrycount = 0 ;
  char ** entry;
  entry = getentryinpath(pathname,&entrycount);
  if ( entry != NULL ){

     if ( strcmp(option,"A") == 0){
        entrydisplay(entry,entrycount,1);  
     }
     if ( strcmp(option,"a") == 0){
        entrydisplay(entry,entrycount,2);
     }
     if ( strcmp(option,"l") == 0){
        entrydisplay(entry,entrycount,11);
     }
     if ( strcmp(option,"c") == 0){
        entrydisplay(entry,entrycount,3);
     }
     if ( strcmp(option,"C") == 0){
        entrydisplay(entry,entrycount,4);
        return;
     }
     if ( strcmp(option,"F") == 0){
        entrydisplay(entry,entrycount,6);
     }
     if ( strcmp(option,"f") == 0){
        entrydisplay(entry,entrycount,7);
     }  
     if ( strcmp(option,"i") == 0){
        entrydisplay(entry,entrycount,9);
     }
     if ( strcmp(option,"n") == 0){
        entrydisplay(entry,entrycount,12);
     }
     if ( strcmp(option,"r") == 0){
        entrydisplay(entry,entrycount,15);
     }
     if ( strcmp(option,"S") == 0){
        entrydisplay(entry,entrycount,16);
     }
     if ( strcmp(option,"s") == 0){
        entrydisplay(entry,entrycount,17);
     }
     if ( strcmp(option,"t") == 0){
        entrydisplay(entry,entrycount,18);
     }
     if ( strcmp(option,"u") == 0){
        entrydisplay(entry,entrycount,19);
     }
  
    freechararray(entry,entrycount);
  }

}

