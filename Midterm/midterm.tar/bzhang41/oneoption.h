#ifndef _ONEOPTION_H
#define _ONEOPTIONS_H
#include <unistd.h>
#include <err.h>
#include <stdio.h>
#include <locale.h>
#include <libgen.h>
#include <sys/param.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <bsd/string.h>
#include <sysexits.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <pwd.h>
#include <grp.h>
#include <linux/kdev_t.h>
#include <time.h>
#include <limits.h>

#ifndef PATH_MAX
#define PATH_MAX 512
#endif

void
lsoneflags(int argc,char** argv, char *flags, int argcc);

void
displayentryinpath( char * pathname, char *option);


void
recursivedisplayentryinpath(char * const *path, char * pathname,
                                char * option, int style);

int
comparename(const FTSENT ** one, const FTSENT** two);

int getoption(char * flags);

#endif
