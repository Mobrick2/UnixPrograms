#ifndef _MYFUN_H
#define _MYFUN_H

#include <unistd.h>
#include <err.h>
#include <stdio.h>
#include <locale.h>
#include <libgen.h>
#include <sys/param.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <bsd/string.h>
#include <sysexits.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <pwd.h>
#include <grp.h>
#include <linux/kdev_t.h>
#include <time.h>
#include <limits.h>
#include <sys/ioctl.h>
#include<fts.h>

#ifndef PATH_MAX
#define PATH_MAX 512
#endif

int
checkfiletype(char * pathname);

char *
getoptionflags(int argc, char** argv);

int
countoptions(char * flags);

void
entrysort(char ** entry, int entrynum);

void
entrydisplay(char **entry, int entrycount, int style);

void
direntrysort(char ** direntry,int dirc);

void
showentryindir(char * pathname, int argcc);

void
lfdisplay(char ** entry,int entrycount, int stlye);
void
displayfilemode(struct stat sb, int style);

void
displaynames(struct stat buf, int maxusername,int maxgroupname, int style);

int
hardlinkcount(int * linkc, char ** entry, int  entrycount, int style);

int
sizecount(int * sizec, char ** entry, int entrycount,int * maxmajor,
                        int * maxminor,int style);

int
blockcount(int *blocknum,char **entry,int entrycount);

int
checklenofnum(int num);

int
calculatemaxuserlen(char** entry, int entrycount,int style);

void
displaytime(struct stat buf);

void
freechararray(char ** entry, int n);

void
ctimedisplay(char ** entry, int entrycount, int style);

void
ctimesort(char** entry, int entrycount);

void
coldisplay(char ** entry, int entrycount, int style);

int
findmaxloc(int * array, int num);

void
pathnamelensort(char ** entry, int entrycount, int *entrylen, int style);


int
findentrylen(char ** entry, int entrycount,int loc, int style);

void
displayentrybyloc(char ** entry, int entrycount, int index,
                int maxlen, int style);

void
specialchardisplay(char ** entry, int entrycount, int style);

void
unsorteddisplay(char ** entry, int entrycount, int style);

void
serialdisplay(char ** entry, int entrycount, int style);

void
entrysizesort(char ** entry, int entrycount);

void
sizedisplay(char ** entry, int entrycount, int style);

void
modifiedtimedisplay(char ** entry, int entrycount, int style);

void
modifiedtimesort(char ** entry, int entrycount);

void
accesstimedisplay(char ** entry, int entrycount, int style);

void
accesstimesort(char ** entry, int entrycount);

char **
getentryinpath(char * pathname, int *count);

int
appendspecialchartoentry(char ** entry, int entrycount);

#endif //End of the MYFUN
